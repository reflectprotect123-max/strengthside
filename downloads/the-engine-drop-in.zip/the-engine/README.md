# The Engine

Conditioning app for two people. Drop this folder in as the root of its own repo.

```
python3 -m http.server 8765
```

Then visit http://127.0.0.1:8765/

## What works now

- Home chart, time in zones, and the Base block (30 to 60 minutes).
- Start easy runs that dose. Two full clocks climb five minutes.
- A finished session summary shows the minutes the clock ran.
- The week label on the card follows today.

## What is not built

- No Garmin CIRQA connection.
- Morning zone lines stay on baseline unless WHOOP recovery is present.
- Live dial color needs something writing live heart rate.

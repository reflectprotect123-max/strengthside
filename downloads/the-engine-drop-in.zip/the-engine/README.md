# The Engine

Conditioning app for two people. Drop this folder in as the root of its own repo.

Open it with any static server from this folder:

```
python3 -m http.server 8765
```

Then visit http://127.0.0.1:8765/

## What works now

- Home: WHOOP dials if connected, heart-rate chart, time in zones.
- Base block only: Steady State Zone 1, 8 weeks, 30 minutes up to 60.
- Start easy runs that dose. Two full clocks move the next session up 5 minutes. Ending short does not.
- Logger horseshoe during the session. Colors stay as they are.
- The other 11 ladders live in `progression.js` and are not on screen.

## What is not built

- No Garmin CIRQA connection. You do not have the band yet.
- Morning Blue and Green lines do not move unless WHOOP recovery is present.
- Live dial color needs a heart-rate source writing `liveHr`. Nothing does that yet.
- Two easy days are not placed on the calendar by themselves.
- Seasons other than Base are not on screen.

## Known review notes

- A finished base session can show 0 minutes on the summary because it skips the normal summary duration step.
- The week label follows the calendar day you are viewing. The dose on the card follows today.

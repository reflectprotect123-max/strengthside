# Full pack — 12 progression models + all notes

**Product:** The Engine (conditioning)  
**Assembled:** 2026-09-24  
**For:** Gemini (or any design / progression review) — upload this whole zip

## Start here

1. **`README.md`** (this file) — map of the zip  
2. **`01-twelve-models/TWELVE-MODELS.md`** — all 12 methods in one place + Hybrid notes  
3. **`01-twelve-models/PER-METHOD-RUNG-LADDERS.md`** — **concrete rung ladders for all 12** (proposed; only Continuous Easy is locked to build next)  
4. **`05-locked-direction/DIRECTION.md`** — what we are building **now** (Continuous Easy 30→60)  
5. **`07-gemini-brief/GEMINI-BRIEF.md`** — answers Gemini’s six prompt questions  

Then open screenshots in `01-twelve-models/screenshots/` while reading the model cards.

## Folder map

| Folder | Contents |
| --- | --- |
| `01-twelve-models/` | Catalogue of all 12 Morph-sourced methods + **all 12 lesson screenshots** + Hybrid adaptation notes + **per-method rung ladders** |
| `02-how-progressions-work/` | How progressions are made, Adaptive Brain design, product rules, 16-week spec, research dossier, modality trees, handoff/manifest |
| `03-formulas-and-rules/` | Approved formulas, RULE-CONFIG JSON, WHOOP→zone layer, training-load model |
| `04-live-vs-morph-audit/` | What is live in the Engine today vs Morph pack gaps (ELI5 + JSON + live kernel snapshot) |
| `05-locked-direction/` | Locked next block: 2× easy continuous, rungs 30→60 |
| `06-extra-ui-refs/` | Home chart/time-in-zones, Morph Chart/Zones UI, logger horseshoe refs |
| `07-gemini-brief/` | Short brief answering audience / metrics / progression / structure / regress / gamification |

## Critical product rules (do not miss)

- Athlete UI brand: **The Engine** — never ship “Morpheus” in the product UI.  
- Zones: **Blue · Green · Red**. Effort: **Easy · Medium · Hard**. **Blue ≠ Easy**.  
- **Next block:** Continuous Easy duration ladder only: `30 → 35 → 40 → 45 → 50 → 55 → 60`.  
- Full 12-method ladder is **catalogue / later**, not this week’s schedule.  
- Do **not** propose a colour re-skin; keep existing Blue/Green/Red tokens.  
- WHOOP: display + zone shift OK; no ML training on WHOOP samples; no endorsement claims.

## Suggested Gemini prompt

> Read `01-twelve-models/TWELVE-MODELS.md`, `05-locked-direction/DIRECTION.md`, and `07-gemini-brief/GEMINI-BRIEF.md`. Use the screenshots. Give design/progression feedback for the **base Continuous Easy block first**. Treat the other 11 methods as a parked catalogue unless a recommendation clearly helps the 30→60 path.

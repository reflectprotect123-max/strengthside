# Gemini brief — The Engine conditioning progression

**Use this zip as context for design / UX / progression feedback in Gemini.**

## What to upload

1. Start with **`GEMINI-BRIEF.md`** (answers the six prompts directly).
2. Attach **`refs/`** if Gemini needs deeper rules or Morph source.
3. Attach **`screenshots/`** for visual tone (Home zones chart + Morph reference).

## Product name

Athlete-facing brand: **The Engine** (conditioning).  
Do **not** brand the UI as Morpheus. Zones are **Blue · Green · Red**. Effort feedback is **Easy · Medium · Hard**.

## Suggested Gemini opener

> Read `GEMINI-BRIEF.md`. Give feedback and design recommendations for the **base-building progression block only** (Continuous Easy 30→60). Park Green/Red method ladder ideas unless they clearly help the base block.

# The Engine — progression brief for Gemini

**Date:** 2026-09-24  
**Product:** The Engine (conditioning half of HYBRID S&C)  
**Audience for this brief:** design / UX / progression feedback  
**Scope for recommendations:** the **base-building block** first (Continuous Easy). Full Blue→Green→Red Morph method ladder is **parked** until base is honest.

---

## 1. Target audience & goals

### Who
- Hybrid / conditioning athletes who already lift or play sport and need a **serious cardio engine** without turning every week into a race plan.
- Primary dogfood user: solo athlete with **WHOOP** + phone logger (bike / rower / fan bike).
- Not a general “steps & calories” fitness crowd. Not combat-sport belt ranks. Not pure endurance race periodization (no marathon peaking UI in this block).

### Main outcome (this phase)
Build an honest **aerobic base**:
- **2 easy continuous sessions per week**
- Grow main work from about **30 minutes → 60 minutes**
- Stay conversational / easy (talk-test feel)
- Use heart-rate **Blue** as the stay-in-zone guide, not as a hardness badge

### Outcome later (not this block)
Eventually unlock harder Morph-style methods (Green / Red intervals) once **2×60 easy** is real. Do not design for that ladder yet unless it clarifies the base path.

### Brand / language rules
| Language | Meaning | Do not confuse with |
| --- | --- | --- |
| **Blue / Green / Red** | Heart-rate **zones** + day module ceiling | Easy / Medium / Hard |
| **Easy / Medium / Hard** | Perceived effort vs intended (in-session only) | Zone colour |
| **watts / RPM / split** | Machine output anchors | Zone colour |

**Hard rule:** Blue ≠ Easy as physiology. Zone colour is HR purpose. EMH is effort feedback.

---

## 2. Core conditioning metrics

### Tracked / shown now (or about to be)
| Metric | Role |
| --- | --- |
| **Heart rate (BPM)** | Live logger dial; zone colour from today’s Blue/Green cutoffs |
| **Today’s zone cutoffs** | Blue bpm / Green bpm (WHOOP recovery can shift them) |
| **HR chart lines** | Morpheus-style vertical bars over the day/session (Home) |
| **Time in zones** | Blue / Green / Red `HH:MM:SS` bars (Home) |
| **Session structure** | Work / rest / rounds, machine target (W / RPM / split) |
| **Effort feedback** | Easy / Medium / Hard after each work interval (when intervals exist) |
| **Completion** | Finished vs planned main minutes (drives Continuous Easy progression) |
| **WHOOP** | Sleep %, Recovery %, Strain (Home dials) — display + zone shift, **not** ML training on WHOOP data |

### Not primary in the base block
- Distance race PRs, XP, badges, streaks, belts
- Numeric RPE 1–10 as the main driver (EMH replaces that for Cond)
- Strength kg / RIR (Engine-only; strength progression removed from this app)

### Density / volume (later)
For interval methods: work duration, rest duration, rounds. For Continuous Easy base: **duration** is the dose lever.

---

## 3. Progression logic & rules

There are **four nested loops**. Only the Continuous Easy between-session piece is the **next product win**.

```
WHOOP morning     → today's Blue/Green BPM + module ceiling
open(anchor)      → starting target (or ask first number)
within-session    → work → rest → EMH → Next output (intervals)
close / between   → confirm anchor · one lever · (later) method ladder
```

### A. Live today (within-session, intervals)
- Athlete performs prescribed work.
- Logs **actual output** + **Easy / Medium / Hard**.
- Brain suggests **Next** from approved EMH tables (Echo RPM deltas, Concept2 watts multipliers).
- Incomplete interval **cannot** earn an increase.
- Missing feedback / missing actual → hold.
- Hard completed as intended = match (hold), not failure.

### B. Next block to build — Continuous Easy ladder (F1)
This is the progression Gemini should design around:

| Rule | Detail |
| --- | --- |
| Frequency | **2** easy continuous sessions / week |
| Start | ~**30:00** main work (week 1 suggestion) |
| Qualify | Finished ≥ **~90%** of planned main minutes |
| Advance | After **2** qualifying exposures → **+5 minutes** |
| Review | Soft review around **45:00** |
| Cap | Automatic ceiling **60:00** (stop auto-adding) |
| Feel | Stay Easy / conversational; do not invent intervals because WHOOP is Green |

**Rungs (duration only):**

`30 → 35 → 40 → 45 → 50 → 55 → 60`

### C. Between-session levers (change only one at a time)
When progressing beyond duration later, Morph trees allow **one** of:
1. Output (watts / RPM / split)  
2. Work duration  
3. Repetitions / rounds  
4. Recovery density  
5. Total Easy duration  

States: `ADVANCE_ONE_LEVER` · `REPEAT` · `REDUCE_OR_STOP` · `HOLD_AFTER_ABSENCE` · `CARDIO_PASS_MECHANICAL_FAIL`

### D. Morning WHOOP rules (zones + ceiling)
| WHOOP recovery | Zone shift | Module ceiling idea |
| --- | --- | --- |
| Green 67–100 | Mild / none | Red allowed — **never auto-upgrade** Easy→harder |
| Yellow 34–66 | Shift down a bit | Cap at Green |
| Red 0–33 | Bigger shift down | Cap at Blue; Easy duration × **0.75** (optional soft) |
| Missing | Baseline zones | Explain “no WHOOP adjustment” |

WHOOP **never overwrites** a confirmed output anchor.  
Terms: display / zone paint OK; do **not** train ML models on WHOOP samples or claim WHOOP endorsement.

---

## 4. System structure (levels / tiers / ranks)

### What we are **not** building for this block
- No Level 1–10 ranks  
- No belts / XP tiers / unlock badges as the progression spine  
- No “you unlocked Red Max” gamification

### What we **are** using

#### Band model (catalogue — parked for later)
Morph-sourced methods, easiest → hardest within then across bands:

**Blue**
1. Steady State Zone 1  
2. Steady State Zone 2  
3. Tempo Intervals  
4. Blue Zone Repeats  

**Green**
5. Green Power  
6. Green Endurance  
7. Green Zone Repeats  
8. Green Threshold  

**Red**
9. Red Power  
10. Red Endurance  
11. Red Threshold  
12. Red Max  

Not all 12 go on the athlete’s two weekly days. Catalogue ≠ schedule.

#### Phase model (current product decision)
| Phase | Structure | Status |
| --- | --- | --- |
| **Base** | Continuous Easy only · 2×/week · 30→60 rungs | **Active direction** |
| **Expand** | Introduce Blue Tempo / Repeats | Later |
| **Raise** | Controlled Green, then Red if ceiling allows | Later |

Think **phase + duration rungs**, not RPG levels.

---

## 5. Regress / deload rules

| Trigger | Intended response |
| --- | --- |
| Missed session | **Hold** last successful dose (`HOLD_AFTER_ABSENCE`). Miss ≠ fail. |
| Finished but < ~90% planned minutes | Do **not** advance duration; stay on same rung (`REPEAT`) |
| WHOOP Red day | Keep training; optionally suggest **0.75 ×** easy duration; stay Blue-purpose |
| WHOOP Green day | Do **not** upgrade Easy into Medium/Hard or invent Red methods |
| Incomplete interval (interval days) | No output increase |
| Pain / illness / collapse | `REDUCE_OR_STOP` — reduce **one** lever or stop |
| HR in zone but mechanical fail | `CARDIO_PASS_MECHANICAL_FAIL` — do not advance output |
| Long absence | Resume last successful Continuous Easy duration; rebuild confidence, don’t leap to 60 |

No shame streaks. No “you broke your streak” punishment as the primary model.

---

## 6. App experience & gamification

### Current / intended tone
- **Performance-driven training logger**, OLED Engine shell.
- Home: WHOOP dials + **Today’s zones** (Morph-style **chart lines** + **time in zones** bars).
- Logger: live HR horseshoe during work/rest; EMH buttons on intervals.
- Calm, serious, base-building. Boring on purpose for this phase.

### Gamification
| Element | In scope? |
| --- | --- |
| XP / badges / unlockables | **No** for this block |
| Streak counters as motivation spine | **No** |
| Visible duration rungs (30…60) | **Yes** — clear progress without game chrome |
| Time-in-zone honesty | **Yes** — show Blue/Green/Red minutes |
| Method “unlock” theatre | **No** until base is done |

### Design asks for Gemini (preferred)
1. How should Home / Training show the **30→60 rungs** without looking like a game XP bar or a dashboard clutter pile?  
2. How should an athlete **see why** they did / didn’t earn +5 (two good finishes rule)?  
3. Empty vs filled **time-in-zones** + chart — how to teach “train to fill” without noise?  
4. Bad-recovery day soft shorten (×0.75) — calm copy + override?  
5. Keep colouring as-is (Blue `#00c2ff`, Green `#3dff7a`, Red `#ff2b2b`, OLED black). **Do not propose a re-skin.**

---

## Locked product decisions (do not reopen unless asked)

- Engine-only athlete app (no hub brain, no strength progression in this shell).  
- 2× easy continuous base toward 2×60.  
- Colouring stays; Morph **lines + time in zones** on Home (horseshoe remains on logger).  
- Skip E3 “full recipe sticky note” identity for now.  
- Do not wire full 12-method ladder before F1 duration ladder works.  
- Never brand UI as Morpheus.

---

## File map in this zip

| Path | Why |
| --- | --- |
| `GEMINI-BRIEF.md` | This file — answers the six prompts |
| `README.md` | How to feed Gemini |
| `refs/DIRECTION.md` | Locked next-block north star |
| `refs/AUDIT-ELI5.md` | Live vs Morph gap IDs in plain English |
| `refs/HOW-PROGRESSIONS-ARE-MADE.md` | Full progression synthesis |
| `refs/00-FORMULAS-AND-RULES.md` | Approved math contracts |
| `refs/00-RULE-CONFIG.json` | EMH tables / Continuous Easy knobs |
| `refs/Morpheus-reference-and-Hybrid-adaptation.md` | 12 methods + Hybrid translation |
| `screenshots/home-zones-chart.png` | Current Home chart + time-in-zones |
| `screenshots/morph_guide_zone_gauges.png` | Morph train Chart / Zones reference |
| `screenshots/01-steady-state-zone-1.png` | Morph Steady State Zone 1 lesson capture |

---

## One-sentence summary for Gemini

> Design feedback for a serious conditioning logger whose **next progression is a quiet Continuous Easy duration ladder (30→60, two quality finishes → +5),** with HR zones and time-in-zone honesty, **no gamified ranks**, and harder Morph methods parked until base is real.

# Per-method rung ladders (all 12)

**Status:** Hybrid **product proposals** for Adaptive Brain / Engine — derived from  
Morph source ranges + Engine one-lever rules + Continuous Easy F1 pattern.  
**Not** Morph’s unpublished algorithm. **Not wired** in the live app yet (except the Continuous Easy idea as locked direction).

**Shared advance rule (all methods):**  
After **2** qualifying exposures at the current rung (complete structure at intended effort, no meaningful collapse) → move **one** rung by the **smallest useful lever**. Borderline → stay. Miss → hold last successful rung. Incomplete → do not advance.

**Shared regress:** reduce **one** lever only (`REDUCE_OR_STOP`). WHOOP Red day may shorten Easy duration ×0.75; Green WHOOP never upgrades the planned method.

**Identity key (when comparing rungs):**  
machine + method + work + recovery + intended effort + output unit.

---

## Legend

| Column | Meaning |
| --- | --- |
| Rung | Step on that method’s ladder (1 = entry) |
| Prescription | Main work structure to show the athlete |
| Primary lever when advancing | What changes on the next rung |
| Notes | Guards / Morph range anchors |

---

## 1. Steady State Zone 1 — Continuous Easy (middle blue)

**Band:** Blue · **Intended effort:** Easy · **Base-block:** YES (locked now)

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 30:00 continuous Easy | — | Suggested week-1 start |
| 2 | 35:00 | duration +5 | Need 2 finishes ≥ ~90% planned |
| 3 | 40:00 | duration +5 | |
| 4 | 45:00 | duration +5 | Soft review |
| 5 | 50:00 | duration +5 | |
| 6 | 55:00 | duration +5 | |
| 7 | 60:00 | duration +5 | **Auto ceiling** — stop auto-adding |

**Qualify:** `completed / planned ≥ 0.90`. Optional fade guard ≤5% if tracking steady output.  
**Do not:** invent intervals, chase watts up while still on this ladder, or skip to Green because WHOOP is Green.

---

## 2. Steady State Zone 2 — Continuous upper blue

**Band:** Blue · **Intended effort:** Easy · **Base-block:** after Z1 honesty (optional Expand)

Same duration spine as Z1, but target **upper blue** HR (not inferred from Easy button alone).

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 20:00 upper-blue continuous | — | Shorter entry than Z1 middle-blue |
| 2 | 25:00 | duration +5 | |
| 3 | 30:00 | duration +5 | |
| 4 | 35:00 | duration +5 | |
| 5 | 40:00 | duration +5 | |
| 6 | 45:00 | duration +5 | Review |
| 7 | 50:00 | duration +5 | Soft cap before mixing with Z1 60 |

**Gate onto this ladder:** athlete can already finish Z1 ≥45 Easy without fading into Green/Red.  
**Do not:** treat Easy button as proof of upper-blue.

---

## 3. Tempo Intervals — short controlled (~70% speed feel)

**Band:** Blue · **Intended effort:** Medium (controlled) · **Base-block:** NO

Morph source: ~10–15 s work / ~60 s active recovery → middle blue; ~10–20 reps.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 10 × 10s / 60s Easy | — | Entry; work = controlled Medium |
| 2 | 12 × 10s / 60s | reps +2 | |
| 3 | 12 × 12s / 60s | work +2s | |
| 4 | 15 × 12s / 60s | reps +3 | |
| 5 | 15 × 15s / 60s | work +3s | Morph upper work band |
| 6 | 18 × 15s / 60s | reps +3 | |
| 7 | 20 × 15s / 60s | reps +2 | Morph upper rep band — hold / reconfirm |

**Advance output** only after structure is stable (separate from rung climb; one lever at a time).  
**Do not:** turn Tempo into maximal sprints.

---

## 4. Blue Zone Repeats — upper blue ↔ middle blue

**Band:** Blue · **Intended effort:** Easy both phases · **Base-block:** NO (early Expand)

Morph source: 30–60 s upper blue / 30–60 s middle blue; source often 2–5 reps early.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 3 × 30s upper / 45s middle | — | Entry |
| 2 | 4 × 30s / 45s | reps +1 | |
| 3 | 4 × 40s / 45s | work +10s | |
| 4 | 5 × 40s / 40s | reps +1; denser rest | One lever preferred — prefer reps first, then densify |
| 5 | 5 × 50s / 40s | work +10s | |
| 6 | 5 × 60s / 45s | work → Morph upper | |
| 7 | 6 × 60s / 45s | reps +1 | Soft ceiling before Green methods |

**Both phases stay Easy.** Higher output phase ≠ Medium.

---

## 5. Green Power — very short maximal

**Band:** Green · **Intended effort:** Hard / maximal · **Base-block:** NO · **Advanced path**

Morph source: 5–10 s max / 40–60 s → middle blue; ~10–20 reps.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 8 × 5s / 50s | — | Entry; quality over volume |
| 2 | 10 × 5s / 50s | reps +2 | |
| 3 | 10 × 6s / 50s | work +1s | |
| 4 | 12 × 6s / 45s | reps +2 | |
| 5 | 12 × 8s / 50s | work +2s | |
| 6 | 15 × 8s / 50s | reps +3 | |
| 7 | 15 × 10s / 55s | work → Morph upper | Hold; do **not** Easy→increase chase |

**Guards:** incomplete / ugly reps cannot advance. Prefer completion + repeatability over EMH-up.

---

## 6. Green Endurance — short maximal, longer recovery

**Band:** Green · **Intended effort:** Hard / maximal · **Base-block:** NO · **Advanced**

Morph source: 10–15 s max / 60–90 s → upper blue; ~10–20 reps.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 8 × 10s / 75s | — | Entry |
| 2 | 10 × 10s / 75s | reps +2 | |
| 3 | 10 × 12s / 75s | work +2s | |
| 4 | 12 × 12s / 70s | reps +2 | |
| 5 | 12 × 15s / 80s | work → Morph upper | |
| 6 | 15 × 15s / 80s | reps +3 | |
| 7 | 18 × 15s / 90s | reps +3; longer rest OK | Soft ceiling ~20 |

Same maximal guards as Green Power.

---

## 7. Green Zone Repeats — upper green ↔ lower green

**Band:** Green · **Intended effort:** Medium/Hard controlled · **Base-block:** NO

Morph source: 30–60 s upper green / 30–60 s lower green; early 3–5 reps.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 3 × 30s upper / 45s lower | — | Entry |
| 2 | 4 × 30s / 45s | reps +1 | |
| 3 | 4 × 40s / 45s | work +10s | |
| 4 | 5 × 40s / 40s | reps +1 | |
| 5 | 5 × 50s / 45s | work +10s | |
| 6 | 5 × 60s / 45s | work → Morph upper | |
| 7 | 6 × 60s / 50s | reps +1 | Soft ceiling |

Distinct work vs recovery targets. Do not collapse into one Easy continuous.

---

## 8. Green Threshold — long sustained green

**Band:** Green · **Intended effort:** Hard controlled · **Base-block:** NO

Morph source: 3–6 min green / 2–4 min → blue; ~2–5 reps. Product example family includes **4 × 5 min**.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 2 × 3:00 / 3:00 Easy | — | Entry |
| 2 | 2 × 4:00 / 3:00 | work +1:00 | |
| 3 | 3 × 4:00 / 3:00 | reps +1 | |
| 4 | 3 × 5:00 / 3:00 | work +1:00 | |
| 5 | 4 × 5:00 / 3:00 | reps +1 | Product hallmark |
| 6 | 4 × 5:00 / 2:30 | denser recovery | One lever — only after #5 stable |
| 7 | 4 × 6:00 / 3:00 | work → Morph upper | Soft ceiling; EMH ≠ threshold proof |

**Do not:** claim physiological threshold from three effort buttons.

---

## 9. Red Power — short max, long blue recovery

**Band:** Red · **Intended effort:** maximal · **Base-block:** NO · **Advanced** · needs module ceiling Red

Morph source: 20–30 s max / 2–3 min → middle blue; ~2–4 reps.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 2 × 20s / 2:30 | — | Entry |
| 2 | 3 × 20s / 2:30 | reps +1 | |
| 3 | 3 × 25s / 2:30 | work +5s | |
| 4 | 3 × 30s / 2:45 | work → Morph upper | |
| 5 | 4 × 30s / 3:00 | reps +1 | Morph upper reps — hold / reconfirm |

**No auto-escalate every interval.** Missed recovery quality → REPEAT, don’t add reps.

---

## 10. Red Endurance — longer max bursts

**Band:** Red · **Intended effort:** maximal · **Base-block:** NO · **Advanced**

Morph source: 40–60 s max / 1–2 min → upper blue; ~2–4 reps.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 2 × 40s / 1:30 | — | Entry |
| 2 | 2 × 50s / 1:45 | work +10s | |
| 3 | 3 × 50s / 1:45 | reps +1 | |
| 4 | 3 × 60s / 2:00 | work → Morph upper | |
| 5 | 4 × 60s / 2:00 | reps +1 | Soft ceiling |

Hard expected; advance on completion + repeatability, not “Hard” alone.

---

## 11. Red Threshold — long near lower red

**Band:** Red · **Intended effort:** Hard sustained · **Base-block:** NO · **Unresolved Morph source**

Morph source: 3–6 min near lower red / 2–4 min → blue; ~2–4 reps — **internally inconsistent** with “100% max” claims.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 2 × 3:00 controlled-hard / 3:00 Easy | — | **Controlled**, not sprint |
| 2 | 2 × 4:00 / 3:00 | work +1:00 | |
| 3 | 3 × 4:00 / 3:00 | reps +1 | |
| 4 | 3 × 5:00 / 3:00 | work +1:00 | |
| 5 | 3 × 6:00 / 3:30 | work → Morph upper | Soft ceiling |

**Explicit:** do **not** implement as 3–6 min all-out sprint power. Resolve source intent before shipping.

---

## 12. Red Max — long maximal efforts

**Band:** Red · **Intended effort:** maximal · **Base-block:** NO · **Advanced**

Morph source: 60–90 s max / several minutes → blue; ~2–4 reps.

| Rung | Prescription | Primary lever | Notes |
| ---: | --- | --- | --- |
| 1 | 2 × 60s / 4:00 Easy | — | Entry |
| 2 | 2 × 75s / 4:00 | work +15s | |
| 3 | 3 × 75s / 4:30 | reps +1 | |
| 4 | 3 × 90s / 5:00 | work → Morph upper | |
| 5 | 4 × 90s / 5:00 | reps +1 | Soft ceiling |

Do not require displayed HRmax. No universal Easy→increase escalation.

---

## Cross-method ladder (when to leave a method family)

Only after Adaptive Brain owns this — **not** calendar auto-advance:

1. Finish Continuous Easy (method 1) toward **2×60** honesty.  
2. Optionally Steady State Z2 / Blue Repeats / Tempo while staying Blue.  
3. Controlled Green (Repeats / Threshold) before Green Power/Endurance.  
4. Red only if **module ceiling** allows and Green controlled work is stable.  
5. WHOOP may force a **down-substitute** for the day; never up-substitute Easy→Red because recovery is Green.

---

## Product example ladder (already in Engine rules — cross-family)

For a return / beginner path that is **not** one Morph screenshot:

`12 × 15s / 45s` → `15 × 15/45` → `2 × 5:00` → `3 × 5:00` → `4 × 5:00`

Short work = controlled / moderately hard, not sprint. This can feed Tempo → Threshold families later; it does not replace method 1 Continuous Easy base.

---

## Wiring priority (locked)

| Priority | What |
| ---: | --- |
| 1 | Method **1** Continuous Easy rungs 30→60 (F1) |
| 2 | Optional WHOOP Red ×0.75 soften on Easy duration |
| 3 | Methods 2–4 Blue expand ladders |
| 4 | Methods 5–12 only after base + ceiling gates |

Until F1 is live, treat rungs 2–12 in this file as **design reference for Gemini / Brain**, not athlete schedule.

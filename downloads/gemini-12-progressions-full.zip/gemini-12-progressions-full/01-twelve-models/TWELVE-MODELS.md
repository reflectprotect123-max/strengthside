# The 12 progression models (Morph-sourced catalogue)

**Source course:** Zone Based Interval Training (Train with Morpheus captures)  
**Hybrid branding:** Blue · Green · Red methods — never label the athlete UI “Morpheus”  
**Status:** Reference catalogue. **Not all 12 are scheduled** on the athlete’s two Cond days.  
**Current product focus:** model **#1 / Continuous Easy path** growing duration `30→60` (see `../05-locked-direction/DIRECTION.md`).

Screenshots: `screenshots/01-…` through `12-…` (full lesson captures).

---

## How to read each card

| Field | Meaning |
| --- | --- |
| Morph work / recovery | What the source lesson shows |
| Hybrid template read | How we translate it into Engine language |
| Band | Blue / Green / Red (HR-zone purpose + difficulty band) |
| Base-block? | Whether it belongs in the locked **now** phase |

---

## Blue band (easiest → harder within Blue)

### 1. Steady State Zone 1
- **Screenshot:** `screenshots/01-steady-state-zone-1.png`
- **Morph work:** Continuous, middle blue  
- **Morph recovery:** none between intervals  
- **Source purpose:** Lowest intensity; recovery + aerobic capacity without stacking fatigue; “stay in the middle of the blue zone”  
- **Hybrid read:** **Easy continuous** — hold on Easy; rate at end of piece  
- **Base-block?** **Yes — primary.** This is the spine of Continuous Easy F1.  
- **Progression lever now:** duration (+5 after 2 qualifying finishes), not output chasing.

### 2. Steady State Zone 2
- **Screenshot:** `screenshots/02-steady-state-zone-2.png`
- **Morph work:** Continuous, upper blue  
- **Morph recovery:** none  
- **Hybrid read:** Sustained Easy base; **do not** infer “upper blue” from the Easy button alone  
- **Base-block?** Optional later within Blue continuous; not required before 2×60 middle-blue honesty.

### 3. Tempo Intervals
- **Screenshot:** `screenshots/03-tempo-intervals.png`
- **Morph work:** 10–15 s ~70% max speed  
- **Morph recovery:** ~60 s active → middle blue  
- **Hybrid read:** Closest to **controlled Medium** short work; Tempo is not “Easy continuous”  
- **Base-block?** **No** — park until base duration ladder works.

### 4. Blue Zone Repeats
- **Screenshot:** `screenshots/04-blue-zone-repeats.png`
- **Morph work:** 30–60 s upper blue  
- **Morph recovery:** 30–60 s middle blue  
- **Hybrid read:** Both phases Easy; higher phase ≠ Medium just because output is a bit higher  
- **Base-block?** **No** — early Expand phase candidate after Continuous Easy is solid.

---

## Green band

### 5. Green Power
- **Screenshot:** `screenshots/05-green-power-intervals.png`
- **Morph work:** 5–10 s maximal  
- **Morph recovery:** 40–60 s → middle blue  
- **Hybrid read:** Advanced; ordinary Easy→increase logic is **unsuitable**  
- **Base-block?** **No.**

### 6. Green Endurance
- **Screenshot:** `screenshots/06-green-endurance-intervals.png`
- **Morph work:** 10–15 s maximal  
- **Morph recovery:** 60–90 s → upper blue  
- **Hybrid read:** Same maximal caveat; converting to Medium creates a different template  
- **Base-block?** **No.**

### 7. Green Zone Repeats
- **Screenshot:** `screenshots/07-green-zone-repeats.png`
- **Morph work:** 30–60 s upper green  
- **Morph recovery:** 30–60 s lower green  
- **Hybrid read:** Distinct work/recovery targets; controlled cardiovascular demand  
- **Base-block?** **No.**

### 8. Green Threshold
- **Screenshot:** `screenshots/08-green-threshold-intervals.png`
- **Morph work:** 3–6 min upper/middle green  
- **Morph recovery:** 2–4 min → blue  
- **Hybrid read:** Controlled long intervals (e.g. 4×5); EMH ≠ physiological threshold proof  
- **Notes:** Source sometimes mentions high recovery score — treat as source claim, not our gate yet  
- **Base-block?** **No.**

---

## Red band (hardest)

### 9. Red Power
- **Screenshot:** `screenshots/09-red-power-intervals.png`
- **Morph work:** 20–30 s max  
- **Morph recovery:** 2–3 min → middle blue  
- **Hybrid read:** Advanced short; no auto-escalate every interval  
- **Base-block?** **No.**

### 10. Red Endurance
- **Screenshot:** `screenshots/10-red-endurance-intervals.png`
- **Morph work:** 40–60 s max  
- **Morph recovery:** 1–2 min → upper blue  
- **Hybrid read:** Hard expected; use completion + output repeatability, not Hard alone  
- **Base-block?** **No.**

### 11. Red Threshold
- **Screenshot:** `screenshots/11-red-threshold-intervals.png`
- **Morph work:** 3–6 min near lower red  
- **Morph recovery:** 2–4 min → blue  
- **Hybrid read:** Source is **internally inconsistent**; do **not** implement as 3–6 min max sprint power  
- **Base-block?** **No** — resolve intent before any product wiring.

### 12. Red Max
- **Screenshot:** `screenshots/12-red-max-intervals.png`
- **Morph work:** 60–90 s max  
- **Morph recovery:** several minutes → blue  
- **Hybrid read:** Do not require hitting displayed HRmax; no universal rating-driven escalation  
- **Base-block?** **No.**

---

## Ladder order (easiest → hardest)

```
1 Steady State Z1
2 Steady State Z2
3 Tempo Intervals
4 Blue Zone Repeats
5 Green Power
6 Green Endurance
7 Green Zone Repeats
8 Green Threshold
9 Red Power
10 Red Endurance
11 Red Threshold
12 Red Max
```

**Method-ladder progression (later Adaptive Brain ownership):**
1. Stay in Blue until Easy continuous + Blue Tempo/Repeats are stable.  
2. Introduce Green controlled formats before Green maximal bursts.  
3. Red only when module ceiling allows **and** Green controlled work is stable.  
4. WHOOP ceiling can force a **substitute down** for the day without rewriting long-term history.  
5. Green WHOOP **never upgrades** a planned Easy/Blue day into Red.

---

## Continuous Easy duration rungs (what we build first)

Separate from climbing 1→12. Same recipe twice a week:

`30 → 35 → 40 → 45 → 50 → 55 → 60` minutes

| Rule | Value |
| --- | --- |
| Sessions / week | 2 |
| Both | Easy continuous |
| Qualify | ≥ ~90% planned main minutes finished |
| Advance | After **2** qualifying exposures → **+5 min** |
| Cap | 60 min auto ceiling |
| Soften (optional) | WHOOP Red day → suggest ×0.75 duration |

This maps to audit ID **F1**. Full 12-method catalogue is **H1**; day-to-day ADVANCE/REPEAT/REDUCE trees are **H2** — both parked until F1 works.

---

## Between-session levers (change only one)

1. Output (watts / RPM / split)  
2. Work duration  
3. Repetitions / rounds  
4. Recovery density  
5. Total Easy duration  

Tree states: `ADVANCE_ONE_LEVER` · `REPEAT` · `REDUCE_OR_STOP` · `HOLD_AFTER_ABSENCE` · `CARDIO_PASS_MECHANICAL_FAIL`  
(see `../02-how-progressions-work/modality_progression_regression_trees.json`)

---

## Conversation / product notes (locked)

- Engine-only athlete app; hub brain removed; adaptive Cond package kept.  
- Home shows Morph-style **chart lines + time in zones**; logger keeps HR **horseshoe**.  
- Colouring stays (no re-skin).  
- Skip E3 full recipe anchor identity for now.  
- Do not wire Green/Red methods “to progress faster” during base.  
- Do not let Green WHOOP turn Easy into Medium/Hard.  
- Do not brand UI as Morpheus.

Full Hybrid adaptation prose: `Morpheus-reference-and-Hybrid-adaptation.md` in this folder.

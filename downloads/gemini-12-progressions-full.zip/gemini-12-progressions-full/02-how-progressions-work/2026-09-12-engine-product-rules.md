# Engine product rules — evidence and implementation checkpoint

Date: 12 September 2026

Status: approved product direction; implementation gaps remain

Scope: conditioning only

## Outcome

The Engine has strong research and method depth but its athlete execution must
stay small: select a session, perform the work, report Easy / Medium / Hard, and
receive the next output target. WHOOP changes the day's three heart-rate zones
and limits the available module before training begins. It does not replace
performed-session evidence.

## Product boundary

| Product | Owns | Does not own |
| --- | --- | --- |
| Engine | Conditioning templates, timers, output, HR zones, WHOOP-informed module selection, Easy/Medium/Hard feedback | Strength sets, kg/reps/RIR, TrainHeroic history, nutrition |
| TRACK / Strength | Strength templates, prescribed sets, kg/reps/RIR, exercise history | Conditioning splits/watts/RPM |
| Brain | Cross-product context and coaching access | A second conditioning decision engine |

## Athlete execution contract

1. Show work time, recovery time, rounds, intended effort and an output target
   when a real anchor exists.
2. Capture actual average watts/RPM/split from a supported connection or one
   simple manual entry. Never imply a device supplied data it cannot supply.
3. During recovery, ask only how the completed work interval felt:
   **Easy / Medium / Hard**.
4. Calculate and display the next output target before the next work interval.
5. Preserve the template's purpose. Feedback adjusts output first; changes to
   work time, recovery or repetitions are between-session programming choices.

No pain prompt is part of this loop. General safety messaging and the athlete's
ability to stop a session remain separate from the adaptation input.

## Within-session decision table

| Intended effort | Easy reported | Medium reported | Hard reported |
| --- | --- | --- | --- |
| Easy | Hold | Small reduction | Small reduction; allow ending the block |
| Medium | Small increase when completion and output are usable | Hold | Small reduction |
| Hard | Small increase only for a controlled-hard method | Hold or gather another observation | Hold when completed as intended; reduce only with failed completion or output collapse |

Rules:

- Missing feedback holds.
- Failed or shortened work cannot earn an increase because it felt Easy.
- Recovery-phase ease says nothing about the preceding work interval.
- For short or noisy efforts, require comparable observations before increasing.
- Keep changes small and method-specific. The previously discussed `+2–3%`
  watts and `+1–2 RPM` are engineering candidates, not validated universal laws.
- Preserve an approximately 10% session-level output-change bound as a candidate
  guardrail until shadow data supports a different value.

## Anchor and history identity

The history key must include:

- machine type and, where available, model;
- method/structure;
- work duration;
- recovery duration;
- intended effort;
- output unit.

If no comparable history exists, start without an invented target. The first
complete observed work interval becomes a provisional anchor. Store observed
output separately from suggested output. Closing a session stores the last
successfully made comparable output; it does not add an automatic bonus.

## Between-session progression

Progress one controllable lever at a time: output, work duration, repetitions,
recovery density, or total easy duration. Do not encode the popular 10% rule as
a safety law.

For one conditioning session each week:

1. Repeat the initial structure until two comparable exposures are completed at
   the intended effort without meaningful output collapse.
2. Progress one lever by the smallest useful step.
3. Repeat the new dose for confirmation.
4. Hold after a borderline exposure; reduce one lever after a clearly incomplete
   exposure.

The two-exposure confirmation is a transparent product heuristic, not a
physiological requirement.

Beginner return example:

`12 × 15 s work / 45 s easy` → `15 × 15/45` → `2 × 5 min` → `3 × 5 min` → `4 × 5 min`

The short work is controlled/moderately hard rather than a sprint. Advancement
depends on the execution rules above, not the calendar alone.

## Method catalogue

The 12 Morpheus references are source families to adapt, not a single mandatory
program:

1. Steady State Zone 1
2. Steady State Zone 2
3. Tempo Intervals
4. Blue Zone Repeats
5. Green Power
6. Green Endurance
7. Green Zone Repeats
8. Green Threshold
9. Red Power
10. Red Endurance
11. Red Threshold
12. Red Max

The Hybrid UI may use plain-language names. Maximal and Red methods require a
separate advanced path. `4 × 5 min` belongs to the sustained controlled-hard
family; the three effort choices do not prove that it occurs at a physiological
threshold.

## WHOOP morning layer

WHOOP Recovery has two separate effects:

1. Calculate today's Blue / Green / Red BPM boundaries from the athlete's
   modality-specific baseline.
2. Limit the highest module available that day.

| WHOOP category | Highest module | Default behavior |
| --- | --- | --- |
| Green, 67–100 | Red | Keep the planned module; never upgrade solely due to Recovery |
| Yellow, 34–66 | Green | Start conservatively; replace planned Red with the closest Green or Blue purpose |
| Red, 0–33 | Blue | Offer lower Blue or rest; replace Green and Red |
| Missing/stale | Planned | Keep baseline zones and state that no current adjustment was applied |

Morpheus publicly documents daily-moving zone boundaries, but the exact general
equation and fitness-level coefficients were not located. WHOOP's proprietary
Recovery score is also not Morpheus Recovery. Therefore the following is only a
candidate V1:

- Start from tested or conservatively estimated modality-specific aerobic and
  anaerobic boundary profiles.
- Express the morning change in heart-rate-reserve percentage points.
- Interpolate `0 / -2 / -5 / -8` percentage points at WHOOP Recovery
  `100 / 67 / 34 / 0`.
- Version the constants, calculate deterministically and run in shadow mode
  before changing athlete prescriptions automatically.

This candidate supersedes the earlier fixed-BPM planning table because HRR
points scale with the athlete's usable range. It is still an original product
hypothesis, not a published Morpheus or WHOOP formula.

## Shadow-mode receipt

Store, at minimum:

- Recovery score, category, source timestamp and freshness;
- zone-rule version, HRrest/HRmax inputs, baseline and daily boundaries;
- planned method/module and delivered substitute;
- intended effort, suggested and observed output for every interval;
- Easy/Medium/Hard feedback and completion;
- next-day Recovery category when available.

Review calibration only after enough comparable sessions exist. Do not silently
personalize from a handful of observations.

## Evidence status and references

Research supports using completed work, RPE/effort, technique and modality-
specific output together, while treating HR as especially limited for judging
short intervals because of response lag. Direct fan-bike research is useful but
too device-specific for universal watts, calories, distance or FTP conversions.

Primary or official reference set:

- Morpheus, “Why Morpheus Uses 3 Dynamic HR Zones Adjusted Daily by Recovery
  Score”: https://support.trainwithmorpheus.com/support/solutions/articles/4000226200-why-morpheus-uses-3-dynamic-hr-zones-adjusted-daily-by-recovery-score
- Morpheus App User Guide:
  https://trainwithmorpheus.com/wp-content/uploads/2019/10/Morpheus-App-User-Guide.pdf
- WHOOP, Recovery overview:
  https://support.whoop.com/s/article/WHOOP-Recovery
- WHOOP, heart-rate zones:
  https://support.whoop.com/s/article/Heart-Rate-Zones
- Buchheit and Laursen, high-intensity interval programming reviews, Parts I and
  II, Sports Medicine (2013): https://pubmed.ncbi.nlm.nih.gov/23539308/ and
  https://pubmed.ncbi.nlm.nih.gov/23832851/
- Foster et al., session-RPE method, Journal of Strength and Conditioning
  Research (2001): https://pubmed.ncbi.nlm.nih.gov/11708692/

The full 12-method screenshots, modality audits, source manifest and 16-week
design remain in the separate focused evidence archive. They are reference
material, not proof that the current code implements this specification.

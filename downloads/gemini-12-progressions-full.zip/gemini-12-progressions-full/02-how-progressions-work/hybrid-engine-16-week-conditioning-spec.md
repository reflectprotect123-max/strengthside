# Hybrid Engine - 16-Week Conditioning Progression

## Purpose

This is the Hybrid Engine adaptation of Aerobic 40 for the agreed weekly chassis:

- Two conditioning sessions per week.
- One Easy Mono session.
- One Moderate Mixed session.
- Sixteen calendar weeks.
- Modality chosen first and progressed consistently.
- No generic easy-aerobic builder, open-ended AMRAP, or random circuit.

The original Aerobic 40 plan has eight source weeks and four sessions per source week. This version keeps the source progression but spreads each source week across two calendar weeks:

| Calendar week | Source material |
|---|---|
| 1 | Source Week 1, short sessions |
| 2 | Source Week 1, long sessions |
| 3 | Source Week 2, short sessions |
| 4 | Source Week 2, long sessions |
| 5 | Source Week 3, short sessions |
| 6 | Source Week 3, long sessions |
| 7 | Source Week 4, short sessions |
| 8 | Source Week 4, long sessions |
| 9 | Source Week 5, short sessions |
| 10 | Source Week 5, long sessions |
| 11 | Source Week 6, short sessions |
| 12 | Source Week 6, long sessions |
| 13 | Source Week 7, short sessions |
| 14 | Source Week 7, long sessions |
| 15 | Source Week 8, short sessions |
| 16 | Source Week 8, long sessions |

## Global rules

### Modality

Choose one primary modality for a four-week wave:

- Bike
- Rower
- Run or walk

Keep that modality for the Easy Mono work and use it for the machine portions of Moderate Mixed where practical. Running is a whole-block substitution, not a set-by-set change, because impact and pacing are different.

Use one primary metric for the block: watts, pace, split, distance, calories, or time. Do not compare raw bike, row, and run numbers as if they were interchangeable.

### Effort

- Easy Mono: RPE 3-4. Conversational, controlled breathing, no sprinting.
- Moderate Mixed: RPE 5-6. Purposeful but sustainable; no local muscular failure.
- A designated comparison week may reach RPE 5, but never becomes a maximal test.
- The source PDF's 70-90 percent language is treated as an effort ladder, not a mandatory heart-rate or pace prescription.

### Standard warm-up

Before each session:

1. Two minutes easy on the chosen modality.
2. Two minutes gradually building to RPE 3.
3. One minute at the planned session effort.
4. Two 15-second technique pickups with 30 seconds easy between them when the session uses intervals.

Finish with three to five minutes easy.

### Progression rule

At a repeated exposure:

1. Complete the full prescription at the target RPE.
2. Keep the same structure next time.
3. Beat the previous output slightly, using the smallest available change.
4. If output drops more than 5 percent or RPE exceeds the cap, repeat or reduce the target by 3-5 percent.

Do not increase output, duration, recovery demand, and movement load at the same time. Mixed-session movement reps stay fixed; scale the variation, height, range, or load to stay moderate.

Every mixed interval is a fixed work window. Complete the listed work, then rest the remainder. There is no AMRAP scoring and no "for time" requirement.

## The 16-week plan

### Week 1 - establish the easy anchor

**Easy Mono - descending ladder**

- 10:00 at RPE 3
- Rest 2:00 easy
- 8:00 at RPE 3-4
- Rest 1:30
- 6:00 at RPE 4
- Rest 1:00
- 4:00 at RPE 4
- Rest 0:30
- 2:00 at RPE 4

Record output for every work interval. The final interval must remain controlled.

**Moderate Mixed - 10 fixed rounds**

Each round:

- One minute on the chosen modality at RPE 5-6.
- Six step-back sprawls.
- Thirty seconds of rope work, low-impact jumping jacks, or lateral line steps.
- Six step-back sprawls.
- One minute easy walk or reset.

### Week 2 - longer easy exposure

**Easy Mono - controlled continuous work**

- Five-minute ramp.
- 25:00 continuous at RPE 3-4.
- Record total distance and average output.

Do not turn this into a benchmark. The goal is an even, repeatable output.

**Moderate Mixed - two fixed 15-minute sets**

Rest two minutes between sets. Within each set, repeat three five-minute clocks:

- One minute modality at RPE 5-6.
- Eight low box step-overs.
- One minute modality.
- Six body rows or band-assisted pulls.
- Rest the remainder of the clock.

### Week 3 - repeated easy intervals

**Easy Mono - two blocks of 90-second intervals**

- Six rounds of 1:30 at RPE 3-4 and 1:00 very easy.
- Rest two minutes.
- Repeat the six-round block.

**Moderate Mixed - 10 fixed rounds**

Each round:

- One minute modality at RPE 5-6.
- Four no-jump burpees.
- Eight anchored sit-ups.
- Four no-jump burpees.
- One minute modality.
- One minute easy walk.

### Week 4 - consolidation

**Easy Mono - reduced long intervals**

- Four rounds of 4:00 at RPE 3-4 and 2:00 very easy.

Hold the Week 3 output. Do not chase an increase.

**Moderate Mixed - one fixed 15-minute set**

Repeat three five-minute clocks:

- One minute modality.
- Ten step-ups or low box step-downs.
- One minute modality.
- Eight hand-release or incline push-ups.
- Rest the remainder of the clock.

### Week 5 - more short-interval volume

**Easy Mono - two blocks of one-minute intervals**

- Eight rounds of 1:00 at RPE 3-4 and 1:00 very easy.
- Rest two minutes.
- Repeat the eight-round block.

**Moderate Mixed - 10 fixed rounds**

Each round:

- One minute modality at RPE 5-6.
- Four box step-downs.
- Six no-jump burpees.
- Four box step-downs.
- One minute modality.
- One minute easy walk.

### Week 6 - short pickups and longer repeats

**Easy Mono**

Block 1:

- Five rounds of 0:30 at RPE 4 and 0:30 easy.

Rest two minutes.

Block 2:

- Ten rounds of 1:00 at RPE 3-4 and 1:00 easy.

**Moderate Mixed - two fixed 15-minute sets**

Rest two minutes between sets. Repeat three five-minute clocks:

- One minute modality.
- Ten controlled elephant-walk steps or bear-crawl steps.
- One minute modality.
- Eight incline or yoga push-ups.
- Rest the remainder of the clock.

### Week 7 - controlled three-speed intervals

**Easy Mono**

Complete 10 rounds of:

- 0:30 at RPE 3.
- 0:30 easy.
- 0:30 at RPE 3-4.
- 0:30 easy.
- 0:30 at RPE 4.
- 0:30 easy.

**Moderate Mixed - 10 fixed rounds**

Each round:

- One minute modality at RPE 5-6.
- Four box step-downs.
- Six hanging knee raises or anchored sit-ups.
- Four box step-downs.
- One minute modality.
- One minute easy walk.

### Week 8 - longer controlled repeats

**Easy Mono**

- Five rounds of 4:00 at RPE 3-4 and 2:00 very easy.

Compare average output with Week 4. Do not exceed the easy-day effort cap.

**Moderate Mixed - two fixed 15-minute sets**

Rest two minutes between sets. Repeat three five-minute clocks:

- One minute modality.
- Ten alternating reverse lunges.
- One minute modality.
- Thirty seconds rope work or low-impact jumping jacks.
- Rest the remainder of the clock.

### Week 9 - increased short-interval volume

**Easy Mono**

- Sixteen rounds of 0:30 at RPE 3-4 and 0:30 easy.
- Rest two minutes.
- Repeat the 16-round block only if the first block stayed clearly below RPE 4.

**Moderate Mixed - two fixed blocks**

Block A, five rounds:

- One minute modality at RPE 5-6.
- Six sprawls.
- One minute modality.
- Ten long-stride walking lunges.
- One minute easy walk.

Rest two minutes.

Block B, five rounds:

- Eight sit-ups.
- One minute modality.
- Thirty seconds rope work or lateral steps.
- One minute modality.
- One minute easy walk.

### Week 10 - longer easy intervals

**Easy Mono**

Block 1:

- Five rounds of 0:30 at RPE 4 and 0:30 easy.

Rest two minutes.

Block 2:

- Five rounds of 3:00 at RPE 3-4 and 1:00 easy.

**Moderate Mixed - two fixed 15-minute sets**

Repeat three five-minute clocks:

- One minute modality.
- Ten alternating curtsy squats or reverse lunges.
- One minute modality.
- Eight elbow-to-tall-plank transitions.
- Rest the remainder of the clock.

### Week 11 - density without a break

**Easy Mono**

- Thirty-two rounds of 0:30 at RPE 3-4 and 0:30 easy.

There is no midpoint break. Hold consistent output across all work intervals.

**Moderate Mixed - two fixed blocks**

Block A, five rounds:

- 0:30 modality at RPE 5-6.
- Six low box step-overs.
- 0:30 rope work or lateral steps.
- 0:30 modality.
- One minute easy walk.

Rest two minutes.

Block B, five rounds:

- 0:30 modality.
- Twelve air squats.
- 0:30 modality.
- Eight anchored sit-ups.
- One minute easy walk.

### Week 12 - deload

**Easy Mono**

Complete four waves with two minutes easy between waves. Each wave is:

- 1:00 at RPE 3.
- 1:00 at RPE 3.
- 1:00 at RPE 3-4.
- 1:00 at RPE 3-4.
- 1:00 at RPE 4.
- 1:00 at RPE 4.

**Moderate Mixed - one fixed 15-minute set**

Repeat three five-minute clocks:

- One minute modality.
- Thirty seconds rope work or low-impact jumping jacks.
- One minute modality.
- Eight box step-downs.
- Rest the remainder of the clock.

Keep the entire session at RPE 5 or below.

### Week 13 - controlled density blocks

**Easy Mono**

Complete 10 rounds of:

- 0:30 at RPE 3.
- 0:30 easy.
- 0:30 at RPE 3-4.
- 0:30 easy.
- 0:30 at RPE 4.
- 0:30 easy.

**Moderate Mixed - fixed three-minute blocks**

Block A: five sets starting every three minutes:

- 0:45 modality.
- Five hanging knee raises or anchored sit-ups.
- Eight box step-downs.
- Five hanging knee raises or anchored sit-ups.
- 0:45 modality.
- Rest until the next start.

Walk two minutes, then repeat Block B for five sets:

- 0:45 modality.
- Four hand-release or incline burpees.
- Ten alternating Cossack squats.
- Four hand-release or incline burpees.
- 0:45 modality.
- Rest until the next start.

### Week 14 - longer repeats and controlled mixed work

**Easy Mono**

- Five rounds of 4:00 at RPE 3-4 and 2:00 very easy.

Aim for even output across all five work intervals.

**Moderate Mixed - two fixed 15-minute sets**

Repeat three five-minute clocks:

- One minute modality.
- Ten alternating Cossack squats.
- One minute modality.
- Eight incline or standard push-ups.
- Rest the remainder of the clock.

### Week 15 - controlled retest preparation

**Easy Mono - benchmark ladder**

Complete two sets:

- 5:00 at RPE 3.
- Rest 1:30.
- 4:00 at RPE 3.
- Rest 1:00.
- 3:00 at RPE 3-4.
- Rest 0:30.
- 2:00 at RPE 4.
- Rest 0:15.
- 1:00 at RPE 4.

Rest one minute between sets. The goal is even, controlled output.

**Moderate Mixed - fixed three-minute blocks**

Block A: five sets starting every three minutes:

- 0:45 modality.
- Four no-jump burpees.
- Eight walking lunges.
- Four no-jump burpees.
- 0:45 modality.
- Rest until the next start.

Walk two minutes, then repeat Block B for five sets:

- 0:45 modality.
- Four box step-downs.
- Eight sprawls.
- Four box step-downs.
- 0:45 modality.
- Rest until the next start.

### Week 16 - controlled benchmark and recovery

**Easy Mono - 20-minute benchmark**

- Five-minute ramp.
- 20:00 at the fastest sustainable pace that remains RPE 5 or below.
- Five-minute easy cooldown.

Record total distance, average output, first-half output, second-half output, and whether the two halves stayed within 5 percent.

**Moderate Mixed - one fixed 15-minute set**

Repeat three five-minute clocks:

- One minute modality.
- Eight sit-ups.
- One minute modality.
- Eight push-ups.
- Rest the remainder of the clock.

Keep the session at RPE 5 or below.

## Substitution rules

- Double-unders: 30 seconds singles, 30 seconds low-impact jumping jacks, or 30 seconds lateral steps.
- Box jump or box jump-over: low box step-up or step-over.
- Sprawl or burpee: step-back sprawl or incline burpee.
- Strict pull-up: band-assisted pull-up or body row.
- Toes-to-bar or hanging knee raise: anchored sit-up.
- Ring dip or ring push-up: push-up variation that leaves at least 3 reps in reserve.
- Wall ball: air squat.
- Kettlebell swing: light dumbbell swing or glute bridge.
- Running: bike, rower, or incline walk for the same prescribed time and RPE.

Preserve the time, reps, and effort target. Do not try to match the original load or distance when the movement changes.

## Completion and progression review

At the end of each four-week wave, review:

- Sessions completed.
- Output at the same RPE.
- Whether work intervals stayed within 5 percent of one another.
- Recovery between sessions.
- Pain, impact tolerance, and movement quality.
- Whether the athlete can progress without increasing fatigue.

Progress the next comparable session only when the prescription was completed, the effort cap was respected, and no pain or recovery warning was present.

# Conditioning research and consolidated design decisions

Conversation update: 12 September 2026. Scope: general conditioning design, app comparisons, research, progression and recovery discussion after the Peak Strength audit. Personal training schedules and personal resting-heart-rate observations are excluded from this update. Existing source material remains historical evidence, not necessarily the current product specification.

## Status and precedence

This document consolidates the later corrections to the conditioning proposal. It supersedes earlier unconditional rules such as Easy always increases output, Hard always decreases output, and every interval must become harder. It records a product design, not an implemented or clinically validated controller. Exact adjustment constants remain unresolved.

The Morpheus reference guide and 14 user-supplied screenshots remain in this pack. Their source prescriptions describe Morpheus. The adaptations below are original proposals and do not reproduce its proprietary algorithms.

## Simple execution

The only conditioning effort responses are **Easy / Medium / Hard**. The prompt refers to the preceding work interval, not how recovered the athlete feels during rest. No pain, technique, readiness or notes prompt is required between intervals.

Flow: show prescribed work and recovery → perform work → start recovery → record output and effort → show next output target before work restarts.

Use interval-average watts when a supported device supplies them. Otherwise permit a simple manual output entry. RPM requires the same machine and resistance setting; cadence alone does not determine power. Rowing stroke rate is not a substitute for rowing watts. Do not assume Garmin or another wearable supplies live power from every gym machine. Showing a target and controlling machine resistance are separate capabilities.

If feedback is omitted, hold the target. If data are missing, do not fabricate output or completion. The athlete can override the suggested output.

## Starting without a test

For an unfamiliar machine and interval format, display duration and intended effort without requiring a max or FTP entry. The athlete's first completed logged interval becomes a provisional output reference. Compare further similar intervals before treating it as reliable. A first burst may be poorly paced; very short efforts need several comparable readings rather than immediate upward adjustment.

Keep history specific to machine, resistance configuration, work duration, recovery structure and intended effort. Do not transfer a 15-second output directly to a five-minute prescription. Within-session corrections are separate from long-term progression: today's reduced target does not automatically rewrite the stable reference for future sessions.

## Effort relative to the prescription

| Planned effort | Reported effort | Proposed interpretation |
|---|---|---|
| Easy | Easy | Target met; hold |
| Easy | Medium or Hard | Consider lower output to preserve easy intent |
| Medium | Easy | Consider a small increase if comparable output and completion support it |
| Medium | Medium | Target met; hold |
| Medium | Hard | Consider a reduction, accounting for interval position and maintained output |
| Hard | Hard | Expected effort may have been achieved; do not reduce automatically |
| Any | No response | No effort-driven change |

Effort often rises across an interval workout even when performance is appropriate. The controller should consider interval number, planned effort, completion and output trajectory. A single late Hard response does not necessarily mean failure. Conversely, unfinished work does not earn progression merely because Easy was selected.

The previously suggested 2–3% watt steps, 1–2 RPM steps, approximate 10% session bound and two-observation confirmation rules are unvalidated engineering examples. They must be tested by machine and format before becoming release defaults. No universal equation was established in this research.

## App comparisons

| Product | Documented workflow | Relevance and limits |
|---|---|---|
| TrainerRoad | Structured power targets, recorded performance, post-workout difficulty feedback and adapted future training. Compatible smart trainers can follow targets in ERG mode. | Closest reference for performance plus effort feedback. ERG resistance matching is not the same as automatically adapting the next target from a rating during rest. |
| Runna | Structured time/distance stages, device guidance and pace recommendations through Pace Insights. | Useful reference for simple execution and automatic stage advancement. Not evidence for our first-interval controller. |
| Garmin Daily Suggested Workouts | Compatible devices recommend workouts from training/device context. | Reference for minimal interaction; not a universal machine-output integration. |
| Athletica | Adaptive endurance planning using performance, training history and recovery context. | Broader adaptation example, with more inputs than our interval interface. |
| Morpheus | Dynamic heart-rate zones, timed work and active recovery, and weekly zone-minute targets. | Guides the athlete to adjust effort toward HR targets; the reviewed documentation did not establish automatic next-interval watts/RPM prescriptions. |

Official references consulted in the conversation:

- TrainerRoad surveys: https://support.trainerroad.com/hc/en-us/articles/4404884465563-What-are-Post-Workout-Surveys
- TrainerRoad ERG: https://support.trainerroad.com/hc/en-us/articles/201869764-Erg-Mode-Explained
- TrainerRoad workout levels: https://support.trainerroad.com/hc/en-us/articles/360061003592-Workout-Levels
- Runna stages: https://support.runna.com/en/articles/15690947-understand-your-runna-workouts
- Runna pace insights: https://support.runna.com/en/articles/14656203-what-are-pace-insights-and-how-do-they-work
- Garmin suggested workouts: https://support.garmin.com/en-US/?faq=oYknGZ910l1pfBNzkDHX6A
- Athletica: https://athletica.ai/sports/running
- Morpheus methods: https://support.trainwithmorpheus.com/support/solutions/articles/4000188205-zone-based-interval-training

Product descriptions are a snapshot of the research, not a continuously refreshed feed or proof of physiological superiority.

## Research supporting effort-guided conditioning

### Ciolac et al. (2015)

Eight healthy young participants completed treadmill intervals guided by heart rate or the Borg 6–20 perceived-exertion scale. One-minute easier and harder periods alternated over 20 minutes. The study found no significant differences in heart-rate responses or walking/running speeds between conditions. This small acute pilot supports the feasibility of perceptual regulation; it does not prove equivalence, long-term superiority or validate three-button automation.

Source: https://pubmed.ncbi.nlm.nih.gov/26028809/

### Seiler and Sjursen (2004)

Twelve trained runners performed self-paced sessions with 1-, 2-, 4- or 6-minute work bouts. Selected speeds differed by duration, and perceived effort rose over the session. This supports format-specific pacing and cautions against interpreting every increase in effort as a reason to lower output. The study used trained runners and a fuller effort scale, not our app.

Source: https://pubmed.ncbi.nlm.nih.gov/15387806/

### Seiler and Sylta (2017)

The analysis covered more than 1,400 sessions from 63 trained male cyclists using 4 × 4, 4 × 8 and 4 × 16-minute formats. Power and perceptual responses differed despite a shared maximal-session-effort instruction. This supports accounting for total work and interval length. It does not supply a next-interval percentage adjustment.

Source: https://pubmed.ncbi.nlm.nih.gov/28051345/

### Evidence boundary

The studies support athlete regulation using perceived effort. None of the reviewed studies directly validated Easy/Medium/Hard as the sole scale, first-interval anchoring, automatic 2–3% watt adjustments, or the same controller across bikes, rowers and SkiErgs. Three labels remain a deliberate interface choice. Physiological threshold estimates cannot be inferred from them alone.

## General progression methods

Progress by comparable completed exposures rather than the calendar. Keep machine and format stable enough to interpret changes. Select a progression lever consistent with the session purpose.

For controlled moderate intervals, the discussed example was duration first, then output:

| Stage | Work | Easy recovery between bouts | Work minutes |
|---|---|---|---:|
| 1 | 4 × 3 min | 2 min | 12 |
| 2 | 4 × 3.5 min | 2 min | 14 |
| 3 | 4 × 4 min | 2 min | 16 |
| 4 | 4 × 4.5 min | 2 min | 18 |
| 5 | 4 × 5 min | 2 min | 20 |

Warm-up and cool-down are additional. This is an illustrative progression, not a universal beginner prescription. Two comparable successful exposures before advancing was proposed as a product confirmation rule. Success means prescribed work completed, reasonably repeatable output and effort appropriate for the session. Repeated difficulty prompts repetition or regression. Once duration is established, output can progress while effort remains appropriate. Do not simultaneously increase output, duration and repetitions while shortening rest.

Power formats need different rules: preserve output quality and suitable recovery rather than automatically increasing duration until the stimulus becomes something else. No fixed calendar frequency is prescribed here.

## Blue intervals, base work and active recovery

Blue Zone Repeats alternate upper and middle blue; Steady State 1 uses gentler continuous work. These categories are heart-rate prescriptions. They do not map directly to the three effort buttons. For an easy-purpose Hybrid session, Easy is success and holds the target.

Distinguish three goals:

- Recovery-focused movement: comfortable activity; no requirement to progress every session.
- Aerobic base development: progressively accumulate manageable easy work; greater output at similar effort can be useful evidence of progress.
- Moderate conditioning: deliberate additional training demand, progressed by its selected work/output rules.

An easy session may feel helpful without necessarily accelerating restoration of strength or reducing muscle damage. The research reviewed was mixed. A cycling-versus-running recovery trial reported some favourable cycling outcomes; another randomized crossover study found cycling did not accelerate recovery after muscle-damaging exercise. This is not direct validation of Morpheus's branded Blue methods. Exercise dose and mode, the preceding task and the outcome measured matter.

Primary references:

- Moderate intensity cycling is better than running on recovery of eccentric exercise-induced muscle damage: https://pubmed.ncbi.nlm.nih.gov/33932873/
- Muscle oxygenation induced by cycling exercise does not accelerate recovery kinetics following exercise-induced muscle damage in humans: https://pubmed.ncbi.nlm.nih.gov/31077799/

Design implication: describe easy conditioning as aerobic training with a manageable fatigue cost. Do not promise that it automatically accelerates recovery or require a recovery score in the interval interface.

## Relationship to strength and open work

The existing Peak Strength/Garage Strength audit remains the strength reference. The agreed strength execution uses weight, completed repetitions and RIR, with the first logged working set establishing a provisional exercise anchor. Conditioning uses output and Easy/Medium/Hard. Both keep the prescription distinct from the observation and distinguish within-session adjustment from future progression.

Remaining implementation work: define machine-specific increments, history comparability, expected effort changes across intervals, handling incomplete/sensor-missing work, and validation against recorded sessions. These remain design tasks. The current ZIP contains reference material and specifications, not a finished adaptive application.

## WHOOP Recovery layer

WHOOP Recovery is proposed as both a daily BPM-zone adjustment and a pre-session module ceiling. Every morning a small, bounded, monotonic shift moves the stored Blue-to-Green and Green-to-Red baseline boundaries; Green permits the scheduled Blue, Green or Red module, Yellow caps selection at Green, and Red caps selection at Blue. A green score never upgrades an easy scheduled session. During training, Easy / Medium / Hard remains the only subjective input and adjusts output within the day's ceiling. Missing WHOOP data uses baseline zones and preserves the planned session.

This follows Morpheus's publicly confirmed architecture—morning recovery moves the estimated aerobic and anaerobic thresholds, while low recovery also limits appropriate intensity—but it does not claim to recreate Morpheus's unpublished equation. The full mechanics, official worked examples, V1 shift table, limitations and validation plan are documented in `../07-wearables-integrations/WHOOP-recovery-to-zone-module-layer.md`.

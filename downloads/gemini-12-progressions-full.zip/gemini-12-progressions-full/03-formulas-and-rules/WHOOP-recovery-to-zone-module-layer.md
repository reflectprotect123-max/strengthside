# WHOOP Recovery to Daily Dynamic Zones and Module Layer

> **SUPERSEDED DESIGN DRAFT — DO NOT IMPLEMENT THE FIXED-BPM TABLE BELOW.** This file is retained as research provenance. The approved experimental V1 uses a continuous, piecewise HRR-percentage-point shift and is specified in `../00-FORMULAS-AND-RULES.md`. Where this document conflicts with a root `00-*` file, the root file is authoritative.

Updated 12 September 2026. This document specifies how WHOOP Recovery can drive a Morpheus-inspired daily conditioning layer. It separates what Morpheus publicly confirms from what remains proprietary, then gives a transparent V1 rule for this system. The V1 rule is an original, configurable product heuristic—not Morpheus's algorithm, WHOOP's recommendation engine, or a clinically validated prescription.

## What Morpheus actually does

Morpheus does two related things after the morning recovery check:

1. It recalculates the actual BPM boundaries between Blue/Low, Green/Moderate and Red/High for that day.
2. It uses recovery context to guide which zones should be trained. Lower boundaries on a poor-recovery day are a warning that physiological cost is higher, not permission to collect easy Green or Red minutes.

Its public workflow is:

- A consistent 2:30 morning measurement records HRV and resting heart rate.
- HRV is compared with a rolling 10-day personal baseline. Unusually low **or unusually high** HRV can reduce recovery.
- Resting heart rate, sleep, recent training load and subjective recovery inputs move the score within the range set mainly by HRV.
- Default zones at 100% recovery are based on maximum heart rate and the selected fitness level. Older documentation also allowed a measured anaerobic threshold to be entered.
- The estimated aerobic and anaerobic threshold boundaries are shifted down when recovery is lower and up toward the 100%-recovery baseline when recovery is higher.
- Without a current recovery test, Morpheus shows baseline rather than dynamically adjusted zones.

Official Morpheus guide screenshots provide a useful worked example for one profile with a displayed maximum heart rate of 192 bpm:

| Morpheus Recovery | Blue/Low | Green/Moderate | Red/High |
|---:|---:|---:|---:|
| 48% | 96–139 | 140–153 | 154–192 |
| 72% | 96–148 | 149–165 | 166–192 |
| 85% | 96–152 | 153–170 | 171–192 |
| 91% | 96–156 | 157–174 | 175–192 |

This confirms that the boundaries themselves move. It does **not** reveal a reliable general formula: the precise zone equation, fitness-level coefficients and full recovery-score weighting are not published in the material located. These screenshots must not be presented as a universal lookup table.

Sources:

- https://support.trainwithmorpheus.com/support/solutions/articles/4000226200-why-morpheus-uses-3-dynamic-hr-zones-adjusted-daily-by-recovery-score
- https://support.trainwithmorpheus.com/support/solutions/articles/4000148285-interpreting-the-results
- https://support.trainwithmorpheus.com/support/solutions/articles/4000148448-max-heart-rate
- https://support.trainwithmorpheus.com/support/solutions/articles/4000230971-morpheus-app-faqs
- https://trainwithmorpheus.com/wp-content/uploads/2019/10/Morpheus-App-User-Guide.pdf

## Important WHOOP difference

WHOOP supplies a vendor Recovery score, not Morpheus's Recovery score. Their colour thresholds also differ:

- WHOOP Green: 67–100%.
- WHOOP Yellow: 34–66%.
- WHOOP Red: 0–33%.

The raw percentage therefore cannot be inserted into an assumed Morpheus equation. Our system uses WHOOP as the morning input but owns and versions its zone-adjustment rule.

Source: https://support.whoop.com/s/article/WHOOP-Recovery

## Our simple daily system

The athlete does nothing beyond wearing WHOOP and opening the app. Each morning the app obtains the current authorized WHOOP Recovery, calculates three BPM zones, and displays them as Blue, Green and Red.

### 1. Establish personal baseline boundaries

Store modality-specific 100%-recovery boundaries where possible:

- `BG_base`: the Blue-to-Green boundary, representing the estimated aerobic threshold.
- `GR_base`: the Green-to-Red boundary, representing the estimated anaerobic threshold.
- `HRmax`: tested or best observed maximum heart rate.

Running, cycling and rowing may use different profiles. A field/lab threshold assessment is preferred; a conservative estimate is only a starting value and should be labelled estimated.

### 2. Calculate a bounded morning shift

For a testable V1, interpolate between these points:

| WHOOP Recovery | Shift applied to both baseline boundaries |
|---:|---:|
| 100 | 0 bpm |
| 67 | −3 bpm |
| 34 | −8 bpm |
| 0 | −12 bpm |

Between points, use straight-line interpolation and round to the nearest whole bpm. Then:

`BG_today = BG_base + shift`

`GR_today = GR_base + shift`

Blue is below `BG_today`, Green is from `BG_today` to below `GR_today`, and Red begins at `GR_today`. The top of Red remains `HRmax`. This is deliberately modest, monotonic and easy to audit. The exact shift values are a **V1 product hypothesis**, not a physiological truth or a reconstruction of Morpheus.

Example with baseline boundaries of 140 and 165 bpm:

| WHOOP Recovery | Daily shift | Blue ceiling | Green ceiling | Red starts |
|---:|---:|---:|---:|---:|
| 85 | −1 bpm | 138 bpm | 163 bpm | 164 bpm |
| 50 | −6 bpm | 133 bpm | 158 bpm | 159 bpm |
| 20 | −10 bpm | 129 bpm | 154 bpm | 155 bpm |

The displayed inclusive ranges depend on the app's boundary convention; internally store the two cut-points to avoid off-by-one errors.

### 3. Keep the module ceiling as a second guardrail

Moving zones is not enough. A low score makes Green and Red easier to enter, so the app must also prevent the athlete from treating lowered zones as permission to do high-intensity work.

| WHOOP Recovery | Module ceiling | Default decision |
|---|---|---|
| Green | Blue, Green or Red | Perform the scheduled module; never upgrade solely because Recovery is green. |
| Yellow | Blue or Green | Start Green at lower work/repetition and higher recovery; replace scheduled Red with the closest Green or Blue purpose. |
| Red | Blue only | Offer lower-end Blue work or rest; replace Green and Red work. |
| Missing/stale | Planned zones and module | Use baseline zones, preserve the planned session and state that no current recovery adjustment was applied. |

This mirrors the logic Morpheus publishes: zones move, while low-recovery days still avoid chasing higher-zone time.

### 4. Tune output during the session

WHOOP sets the morning zones and module ceiling. Easy / Medium / Hard remains the only athlete-entered conditioning feedback. It adjusts the next watts or RPM suggestion within the permitted module; it never unlocks a higher category that morning.

## Execution order

1. Fetch today's WHOOP Recovery and timestamp.
2. Select the correct modality profile and its baseline boundaries.
3. Apply the bounded daily BPM shift, or use baseline zones if data is missing/stale.
4. Apply the WHOOP module ceiling to the scheduled session.
5. Display only today's Blue, Green and Red ranges plus the session.
6. During intervals, use Easy / Medium / Hard to tune the next output.
7. Keep the morning adjustment separate from long-term fitness progression; a single poor day does not rewrite baseline capacity.

## Validation before automatic release

Run the rule in shadow mode first. For each session store WHOOP score and timestamp, baseline and daily boundaries, planned and delivered module, HR, watts/RPM, Easy/Medium/Hard feedback, completion and next-day recovery category. Check whether lower zones reduce excessive Hard ratings and whether Green mornings permit productive work without worsening multi-day trends.

Change the four shift anchors only through a versioned calibration update. Do not silently personalize from a handful of sessions. A measured threshold update changes the baseline profile; a daily recovery score changes only that day's working boundaries.

WHOOP's Project PR is a vendor-reported precedent for recovery-guided changes in running volume/intensity, not validation of this BPM-shift formula. A peer-reviewed WHOOP 2.0 study supported aspects of HR/HRV measurement but explicitly did not validate the proprietary composite Recovery Score. The V1 rule therefore needs prospective validation and clear user-facing wording.

Sources:

- https://www.whoop.com/us/en/thelocker/podcast-107-project-pr-study-validates-recovery/
- https://pmc.ncbi.nlm.nih.gov/articles/PMC8160717/

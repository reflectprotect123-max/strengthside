# Direction — where this should head

## Your stated next block (locked in conversation)

- **2 conditioning sessions per week**
- **Both easy** (base building — not Green/Red methods yet)
- Grow toward **2 × 60 minutes**
- Suggested week-1 main work: **30 minutes** each (Morph locks +5 steps and 60 cap; it does not hard-require 30)
- Ladder: `30 → 35 → 40 → 45 → 50 → 55 → 60` after qualifying finishes
- **E3 (recipe sticky notes)** — skip for now
- **Hard / interval Morph catalogue** — park until base is built

## North star for this block

> Two easy continuous sessions a week. Finish most of the time. After two good ones, add five minutes. Stop auto-adding at 60. Stay conversational / easy. Use WHOOP only to paint zones and optionally shorten a bad day — not to invent hard intervals.

That is Morph’s **Continuous Easy** path (F1), not the full Blue→Green→Red ladder.

## Recommended build order (when you allow wiring)

Do **not** start with the 12-method library. For this block, order is:

### 1. Continuous Easy duration progression (F1) — first product win
- Piece type: steady / continuous, intended Easy  
- Qualifying: finished ≥ ~90% of planned main minutes (Morph rule)  
- After **2** qualifying exposures on that path: **+5 minutes**  
- Review at 45; **auto ceiling 60**  
- Both weekly sessions share this base ladder (same recipe twice/week is fine for base)

### 2. Optional morning soften on bad recovery (G4, light)
- If WHOOP Red: suggest **0.75 ×** planned easy duration that day (athlete can override)  
- Do **not** cancel training; do **not** upgrade to hard work because recovery is Green (Morph non‑negotiable)

### 3. Clean the dormant fork (I1 / C2 / J1)
- Either delete or quarantine adaptive RPE `decideNextCond` so there is **one** Next authority (live EMH kernel)  
- Decide later whether `softenOpen` applies to *output* on easy continuous or only duration — for base block, prefer **duration** lever only

### 4. Still park for later (after base)
- H1 method catalogue under Blue/Green/Red  
- H2 ADVANCE_ONE_LEVER trees across methods  
- G3 full module-ceiling method substitution  
- E3 full recipe anchor identity  

### 5. Keep as-is (already good enough for base)
- A1/A2 EMH tables (useful if an easy day still has short controlled pieces)  
- B1 incomplete cannot increase  
- D1 watts-path split  
- G1 zone paint  
- H3 Blue ≠ Easy  

## What “done” looks like for the base block

An athlete can:

1. See two easy continuous sessions on the week  
2. Start near **30:00** main work  
3. Log finish time / completion  
4. After two solid weeks of finishes, open the next session at **+5:00** without hand-editing  
5. Cap at **60:00** without the app inventing intervals or Red methods  
6. Still see WHOOP Sleep / Recovery / Strain and the horseshoe  

## What not to do in this block

- Do not schedule Morph Green/Red power methods “to progress faster”  
- Do not let Green WHOOP turn Easy into Medium/Hard  
- Do not sell or train models on WHOOP samples (API terms)  
- Do not brand the UI as Morpheus  
- Do not wire the full 12-method ladder before the 30→60 easy ladder works  

## Mapping to audit IDs

| Priority | IDs | Action |
| --- | --- | --- |
| Now (concept) | F1 | Continuous easy +5 toward 2×60 |
| Soon (optional) | G4 | Red day shortens easy duration |
| Hygiene | I1, C2, J1 | One Next brain |
| Later | H1, H2, G3, E3 | Ladder + ceiling + recipe keys |
| Keep | A1, A2, B1, C1, D1, E1, G1, G5, H3, I2 | Already live |

## Tone of the product for this phase

Base. Boring on purpose. Time in zone. Two days. Grow the clock. Harder Morph methods wait until 2×60 easy is honest.

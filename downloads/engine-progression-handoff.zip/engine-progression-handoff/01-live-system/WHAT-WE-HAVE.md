# What we have (live Engine)

Branch: `cursor/engine-only-fb1e`. Product is Engine-only + adaptive conditioning package. Hub brain packet is gone. WHOOP connect/sync remains.

## The loop that actually runs

1. **Open** — If the piece has a typed watts / split / rpm, use it. Else use the last saved number for that machine. Else ask for a first number. Walk/run have no number.
2. **Work** — Timer runs the bout.
3. **Effort** — Athlete taps Easy / Medium / Hard (vs what the piece intended).
4. **Next** — `brain-kernel.js` nudges rpm (Echo table) or watts (Concept2 table). Row/ski convert through watts. Incomplete bouts cannot get harder.
5. **Close** — If two bout numbers agree (watts within ~3%, rpm within 1), lock a provisional/confirmed anchor for next time.
6. **Morning** — WHOOP recovery moves today’s Blue/Green heart-rate lines on Home. It also *computes* a module ceiling (blue/green/red) but **does not** swap or block workouts.

## Files that matter

| File | Role |
| --- | --- |
| `brain-kernel.js` (in this folder) | Live EMH tables, confirmAnchor, dailyZones |
| `apps/athlete/engine.js` | openPiece, recordEffort, closePiece, split↔watts |
| `apps/athlete/logger.js` | UI that calls recordEffort |
| `adaptive-decide-next-cond.ts` | **Unused** by logger — RPE/cooked path |
| `adaptive-map-from-2k.ts` | 2k bands + `softenOpen` — soften unused by logger |

## What we do *not* have wired

- Morph’s 12 named methods under Blue / Green / Red in Library  
- Between-session ADVANCE / REPEAT / REDUCE trees  
- Continuous easy: 90% finish → after 2 good ones → +5 minutes (cap 60)  
- WHOOP ceiling substituting methods or cutting easy duration by 25% on Red  
- Full “sticky note remembers the recipe” anchor identity (skipped for now in planning)

## Honest size of the live system

Strong at **inside one interval session**.  
Thin at **week-to-week base building** and **method ladder**.

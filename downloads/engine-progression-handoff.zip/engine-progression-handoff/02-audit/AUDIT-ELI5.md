# Audit rows — plain English

Machine matrix: `progression_dual_audit.json`  
Gates: G1 live inventory, G2 athlete suite green, G3 dual Morph audit — all met (see logs).

| ID | Plain English | Live vs Morph |
| --- | --- | --- |
| A1 | Fan bike effort table | Match |
| A2 | Watts effort table | Match |
| B1 | Quit early → target cannot go up | Done |
| C1 | Easy/Medium/Hard after work | Done |
| C2 | Spare RPE brain still in adaptive package | Unused / risk |
| D1 | Split math via watts | Done |
| E1 | Open from typed / last / first number | Done |
| E2 | Lock after two similar numbers | Partial (Morph wants smarter lock) |
| E3 | Sticky note remembers full recipe | Missing — **skipped for now** |
| F1 | Easy continuous +5 min ladder | Missing — **next block needs this idea** |
| G1 | WHOOP moves HR zone lines | Done |
| G2 | Computes “only Blue/Green/Red today” | Computed only |
| G3 | Actually swaps/blocks methods with that | Not wired |
| G4 | Bad recovery → shorten easy by 25% | Missing |
| G5 | WHOOP doesn’t erase saved watts | OK |
| H1 | 12 Morph methods in Library | Missing |
| H2 | Day-to-day advance/repeat/reduce brain | Missing |
| H3 | Easy button ≠ Blue zone | Respected |
| I1 | Two Next recipes (kernel vs adaptive) | Dormant split-brain |
| I2 | No lift progression in Engine | Removed (good) |
| J1 | Soften open target from recovery | Written, unused |

**Scoreboard:** ~half aligned, ~quarter soft gaps, ~third Morph ladder missing.

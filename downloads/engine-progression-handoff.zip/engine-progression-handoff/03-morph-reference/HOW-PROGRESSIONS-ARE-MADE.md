# How / what progressions are made

**Audience:** Adaptive Brain progression bundle work  
**Date assembled:** 2026-09-16  
**Authority stack (when sources conflict):**

1. `sources/00-FORMULAS-AND-RULES.md` + `sources/00-RULE-CONFIG.json` + Adaptive Brain V1 design  
2. Live `sources/brain-kernel.js` (implemented math today)  
3. `sources/Morpheus-reference-and-Hybrid-adaptation.md` + `sources/2026-09-12-engine-product-rules.md`  
4. 16-week spec + modality trees + research dossiers  
5. Older RPE-slider / RIR Cond specs → historical only  

**Product branding:** never ship “Morpheus” in athlete UI. Hybrid language is **Blue · Green · Red** (HR zones / modules) and **Easy · Medium · Hard** (effort feedback).

---

## 0. What this pack is for

You are building progression into **Adaptive Brain**. Engine Library will eventually **work with** methods (pick / run), not invent them.

This zip gives you:

| Folder | Contents |
| --- | --- |
| `screenshots/` | 12 Morph Hub lesson captures, Blue→Green→Red, easiest→hardest |
| `HOW-PROGRESSIONS-ARE-MADE.md` | This synthesis (start here) |
| `sources/` | Authoritative contracts, Morph adaptation, WHOOP layer, 16-week plan, trees, live kernel |

---

## 1. Three languages that must not be collapsed

| Language | Meaning | Who uses it |
| --- | --- | --- |
| **Blue / Green / Red** | Heart-rate **zones** and day **module ceiling** | Morph methods; WHOOP morning layer; dial UI |
| **Easy / Medium / Hard** | Athlete **effort feedback** vs intended effort | Only in-session logging; Brain `decideNext` |
| **watts / RPM / split** | Machine **output anchors** | Within-session Next; between-session confirmed anchors |

**Hard rule from Morph adaptation:** Blue ≠ Easy as physiology. Zone colour is HR-zone purpose. EMH is perceived effort vs intended. UI-only fallback when no live HR: Easy→blue ring, Medium→green, Hard→red.

---

## 2. Library shape (product): work with methods

Three headings. Listed **easiest → hardest** within the band, then **progress across bands** when Adaptive Brain says so.

### Blue (easiest band)

| # | Method | Morph work (source) | Morph recovery | Hybrid template read |
| --- | --- | --- | --- | --- |
| 1 | Steady State Zone 1 | Continuous, middle blue | — | Easy continuous; hold on Easy; rate end-of-piece |
| 2 | Steady State Zone 2 | Continuous, upper blue | — | Sustained Easy base; do **not** infer upper-blue from Easy button |
| 3 | Tempo Intervals | 10–15 s ~70% max speed | 60 s active → middle blue | Closest to controlled Medium short work |
| 4 | Blue Zone Repeats | 30–60 s upper blue | 30–60 s middle blue | Both phases Easy; higher phase ≠ Medium |

### Green

| # | Method | Morph work | Morph recovery | Hybrid template read |
| --- | --- | --- | --- | --- |
| 5 | Green Power | 5–10 s maximal | 40–60 s → middle blue | Advanced; ordinary Easy→increase logic **unsuitable** |
| 6 | Green Endurance | 10–15 s maximal | 60–90 s → upper blue | Same; converting to Medium = different template |
| 7 | Green Zone Repeats | 30–60 s upper green | 30–60 s lower green | Distinct work/recovery targets |
| 8 | Green Threshold | 3–6 min upper/middle green | 2–4 min → blue | Controlled long intervals (e.g. 4×5); EMH ≠ threshold proof |

### Red (hardest band)

| # | Method | Morph work | Morph recovery | Hybrid template read |
| --- | --- | --- | --- | --- |
| 9 | Red Power | 20–30 s max | 2–3 min → middle blue | Advanced short; no auto-escalate every interval |
| 10 | Red Endurance | 40–60 s max | 1–2 min → upper blue | Hard expected; use completion/repeatability |
| 11 | Red Threshold | 3–6 min near lower red | 2–4 min → blue | Source inconsistent; do **not** implement as 3–6 min max sprint |
| 12 | Red Max | 60–90 s max | Several min → blue | Do not require displayed HRmax; no universal rating escalation |

Screenshots: `screenshots/01-…` through `12-…`. Full tables: `sources/Morpheus-reference-and-Hybrid-adaptation.md`.

**Not all 12 go on the athlete’s two weekly Cond days.** Catalogue expands the library; scheduling is Brain + coach/athlete choice.

---

## 3. Ownership: who progresses what

| Surface | Owns | Athlete input |
| --- | --- | --- |
| **Engine** | Methods, timers, HR zones UI, output capture, EMH prompt | Actual output + Easy/Medium/Hard |
| **Adaptive Brain** | Deterministic `open` / `decideNext` / `close` | No athlete UI |
| **WHOOP morning** | Recovery → daily BPM cutpoints + **module ceiling** | Auto import |
| **Strength / TRACK** | Separate pillar (same EMH principle, different maths) | kg / reps / EMH |

Shared principle:

> **Suggest → perform → log actual + effort → calculate from the actual.**  
> Never store a suggestion as an observed value.

---

## 4. How progressions are made (four layers)

Think of four nested loops. Brain owns decisions; Engine owns capture/UI.

```
WHOOP morning          →  today's BG/GR BPM + module ceiling (Blue/Green/Red)
       ↓
open(anchor)           →  starting target (or needsFirstNumber)
       ↓
within-session loop    →  work → rest → EMH → decideNext(output)
       ↓
close / between-session→  confirm anchor · one-lever progression · method ladder
```

### 4.1 Morning: WHOOP → zones + module ceiling

**Zones (HRR shift, approved experimental V1)** — `00-FORMULAS-AND-RULES.md` §8, live in `brain-kernel.js` `dailyZones` / `shiftHrrPoints`:

| WHOOP Recovery R | Shift S (HRR %-points) |
| ---: | ---: |
| 0 | −8 |
| 34 | −5 |
| 67 | −2 |
| 100 | 0 |

Piecewise linear between those knots. Then:

`BG_today = BG_base + (S/100)×HRR`  
`GR_today = GR_base + (S/100)×HRR`

Baseline (Karvonen fallback if no measured thresholds):

`BG_base ≈ RHR_28 + 0.60×HRR`  
`GR_base ≈ RHR_28 + 0.85×HRR`  
`Blue_floor ≈ RHR_28 + 0.40×HRR` (display only)

**Module ceiling** — highest **band** allowed that day:

| WHOOP category | Ceiling | Behavior |
| --- | --- | --- |
| Green 67–100 | Red | Keep scheduled module; **never auto-upgrade** Easy→harder |
| Yellow 34–66 | Green | Replace planned Red with closest Green/Blue purpose |
| Red 0–33 | Blue | Replace Green/Red with Blue; Easy duration × **0.75** |
| Missing/stale | Planned | Baseline zones; explain no adjustment |

WHOOP **never overwrites** a confirmed output anchor.  
Coefficients are **Hybrid product heuristics**, not Morph’s unpublished formula and not WHOOP’s internal math. Shadow receipts required before trusting live auto-substitution.

### 4.2 Open: start from last confirmed (or ask for first number)

`open({ kind: 'engine', anchor })`:

- Confirmed or provisional anchor with output → that target  
- Else → `needsFirstNumber: true` (athlete picks; first complete actual = provisional)

**Anchor identity (comparability key):**

`athlete + machine_type + machine_model + method + work_duration + recovery_duration + intended_effort + output_unit`

Any material change → new comparison group. Seed from nearby prior only with confidence reset.

### 4.3 Within-session: EMH → Next output (one interval at a time)

Athlete loop (Engine):

1. Show work / rest / rounds / intended effort / target (if any)  
2. Run work; capture average watts/RPM/split (or one manual entry)  
3. During rest, ask **only** Easy / Medium / Hard for the **work** interval  
4. Brain `decideNext` → show next target before next work  

**Approved tables** (`00-RULE-CONFIG.json` / `brain-kernel.js`):

**Echo Bike (RPM deltas):**

| Intended \\ Reported | Easy | Medium | Hard |
| --- | ---: | ---: | ---: |
| Easy | 0 | −1 | −2 |
| Medium | +1 | 0 | −1 |
| Hard | +2 | +1 | 0 |

**Concept2 family (watts multipliers; then convert to split):**

| Intended \\ Reported | Easy | Medium | Hard |
| --- | ---: | ---: | ---: |
| Easy | ×1.00 | ×0.97 | ×0.95 |
| Medium | ×1.03 | ×1.00 | ×0.97 |
| Hard | ×1.05 | ×1.03 | ×1.00 |

**Guards (non-negotiable):**

- Incomplete interval **cannot** earn an increase  
- Missing feedback / missing actual → hold  
- Recovery-phase “felt easy” is **not** evidence about the work interval  
- Hard completed as intended = **match** (hold), not failure  
- Short/noisy efforts need comparable observations before up  
- Candidate session guardrail: ~10% bound on total output drift (engineering, not law)

**Maximal / Red Morph formats:** do not run ordinary Easy→increase chasing. Prefer completion + output repeatability; separate advanced path.

### 4.4 Close: confirm anchors; between-session progress one lever

**Confirm controlled intervals** after ≥2 qualifying observations (complete, usable actual, reported effort **matches intended**), not necessarily consecutive:

- watts: `|w2−w1| / median ≤ 0.03`  
- Echo RPM: `|rpm2−rpm1| ≤ 1`  
- Confirmed anchor = **median** of qualifying actuals  

**Continuous Easy** (Steady State path):

- Qualify if `completed / recovery_adjusted_duration ≥ 0.90`  
- Fade ≤ 5% first→final steady block required for **upward output** confirm  
- After **2** qualifying exposures: `duration += 5 min`  
- Review at 45 min; automatic ceiling 60 min  

**Between-session levers (change only one):**

1. Output (watts/RPM/split)  
2. Work duration  
3. Repetitions / rounds  
4. Recovery density  
5. Total Easy duration  

States from modality trees (`sources/modality_progression_regression_trees.json`):

| State | Meaning |
| --- | --- |
| `ADVANCE_ONE_LEVER` | Progress one dose variable after stable comparable execution |
| `REPEAT` | Borderline / need confirmation / uncertainty |
| `REDUCE_OR_STOP` | Pain, unsafe technique, collapse, illness |
| `HOLD_AFTER_ABSENCE` | Miss ≠ fail; resume last successful dose |
| `CARDIO_PASS_MECHANICAL_FAIL` | HR target met but mechanical work failed → do not advance |

Pattern:

`complete at intended → same structure → smallest useful bump → reconfirm → hold if borderline → reduce one lever if clearly incomplete`

Example beginner ladder (product rules doc):

`12×15s/45s → 15×15/45 → 2×5 min → 3×5 min → 4×5 min`  
(short work = controlled/moderately hard, not sprint)

### 4.5 Method-ladder progression (Blue → Green → Red)

This is the piece **Adaptive Brain** still needs to own as a first-class progression object (beyond within-method output/duration):

1. **Stay inside Blue** until Easy continuous + Blue Tempo/Repeats are stable (compliance + anchors).  
2. **Introduce Green** controlled formats (Threshold / Repeats) before Green Power/Endurance maximal bursts.  
3. **Red** only when module ceiling allows **and** Green controlled work is stable; Power/Max are advanced, not default weekly load.  
4. WHOOP ceiling can **force a substitute down the ladder** for the day without rewriting long-term method history.  
5. Green WHOOP **never upgrades** a planned Easy/Blue day into Red.

Morph screenshots are the **structure source** (work/rest/purpose). Hybrid progression is **evidence + one lever + module gate**, not calendar auto-advance through all 12.

---

## 5. Piece model (what Engine stores)

Typical Engine piece fields (library / logger):

- `structure` (e.g. intervals / continuous)  
- `effort` (intended: easy | medium | hard)  
- `workSec`, `restSec`, `rounds`  
- typed / anchored output: watts | rpm | split  
- machine / modality  

Phases in live logger: `ready → work → tapRest → rest → (effort) → next`  
Cond Next stays **watts/RPM**, not HR-driven. HR drives zone dial colour / WHOOP gates.

---

## 6. 16-week chassis (existing program spine)

`sources/hybrid-engine-16-week-conditioning-spec.md` — Hybrid adaptation of Aerobic 40:

- **2 Cond days / week:** Easy Mono + Moderate Mixed  
- 16 calendar weeks = 8 source weeks × (short then long)  
- Modality wave (bike / rower / run) for 4 weeks  
- Progress: complete @ target RPE → same structure → smallest output bump; >5% drop or RPE over → repeat / −3–5%  
- **One lever only**  

This is the **calendar spine**. Morph 12-method catalogue is the **method vocabulary** that Library headings Blue/Green/Red should expose; Brain decides when a method from that vocabulary is eligible.

---

## 7. Training-load context (do not confuse with Next)

`sources/training-load-model.md`:

- Cardio channel: zone / TRIMP / session-RPE style load  
- Strength channel: tonnage  
- Morph precedent mapping for load bands: Recovery/blue ≈ Z1–2, Conditioning/green ≈ Z3–4, Overload/red ≈ Z5  

Load accounting ≠ interval Next maths. Use for weekly dose awareness, not to drive +1 RPM.

---

## 8. Implementation honesty (gaps Brain must close)

From `00-HANDOFF.md` — target contract vs older Engine adaptive code:

| Contract | Status note |
| --- | --- |
| EMH enums (not numeric RPE / cooked) | V1 direction; some older paths still RPE/% |
| Echo / Concept2 tables above | In `brain-kernel.js` |
| Anchor confirm + median | In kernel `confirmAnchor` |
| Continuous Easy 90% / 5% fade / +5 min | Spec’d; wire end-to-end in Brain |
| WHOOP HRR shift + module ceiling | Kernel `dailyZones`; UI/shadow receipts still product work |
| Method-ladder Blue→Green→Red | **Your progression bundle** — not fully encoded as a single state machine yet |
| Morph method catalogue in Library UI | Product next (Engine Library headings) |

Do **not** market constants (1 RPM, 3%, 2 observations, 90%, 5% fade, 5 min, WHOOP HRR points) as physiological laws. They are versioned product heuristics.

---

## 9. What Adaptive Brain should produce from this pack

A progression bundle that can answer, deterministically:

1. **Today’s module ceiling** given WHOOP freshness + recovery  
2. **Eligible methods** from the 12 (filtered by ceiling + athlete history)  
3. **`open` target** for the chosen method/machine/structure  
4. **`decideNext`** after each EMH + actual  
5. **`close`** → provisional/confirmed anchor update  
6. **Between-session recommendation:** REPEAT | ADVANCE_ONE_LEVER | REDUCE | HOLD_AFTER_ABSENCE | substitute-down-band  
7. **Receipts** for shadow review (recovery, zones, planned vs delivered method, every interval’s suggested/actual/EMH)

Engine then: list methods under Blue / Green / Red, run the piece, show dial BPM + zone tone, ask EMH, display Next.

---

## 10. Source index (full copies in `sources/`)

| File | Role |
| --- | --- |
| `00-FORMULAS-AND-RULES.md` | Executable maths + tables |
| `00-RULE-CONFIG.json` | Machine-readable constants |
| `00-HANDOFF.md` | Locked product decisions + gaps |
| `00-MANIFEST.md` | Package authority map |
| `2026-09-13-adaptivebrain-v1-design.md` | Brain API V1 |
| `2026-09-12-engine-product-rules.md` | Condensed Engine rules |
| `Morpheus-reference-and-Hybrid-adaptation.md` | 12 methods + Hybrid EMH adaptation |
| `WHOOP-recovery-to-zone-module-layer.md` | WHOOP provenance (fixed-BPM table superseded) |
| `hybrid-engine-16-week-conditioning-spec.md` | 16-week Easy/Moderate spine |
| `modality_progression_regression_trees.json` | Shared ADVANCE/REPEAT/REDUCE trees |
| `Conditioning-research-and-design-consolidated.md` | Later corrections (one-lever, Blue≠EMH) |
| `training-load-model.md` | Two-channel load model |
| `brain-kernel.js` | Live open/decideNext/close/zones implementation |

---

## 11. Non-negotiables (copy into Brain checklist)

- Do not claim V1 daily-zone maths is Morph’s formula.  
- Do not transfer anchors across machines or materially different protocols.  
- Do not calculate Concept2 Next as linear split-second fudge; use watts.  
- Do not let WHOOP overwrite confirmed anchors.  
- Do not let incomplete work earn an increase.  
- Do not confuse intended Hard with failure.  
- Do not auto-upgrade planned Easy because WHOOP is Green.  
- Do not schedule all 12 Morph methods into two weekly days by default.  
- Do not brand athlete UI as Morpheus.

# Morpheus references and Hybrid conditioning adaptation

Updated 12 September 2026. Source: 14 screenshots supplied by the user in this conversation, preserved unchanged in `../05-source-programs/morpheus-user-supplied/`. These cover all 12 written method descriptions, with additional captures for Green Zone Repeats and Red Endurance. This is a reference and design document, not a claim that the Hybrid app has been implemented or that its controller has been validated.

## Reference index

The timings and targets below describe the supplied Morpheus material. They are not automatic starting prescriptions for the user. Blue, green and red refer to Morpheus heart-rate zones, not our effort buttons. Workout times exclude warm-up and cool-down unless stated.

| Method | Source screenshot number | Source work | Source recovery | Source volume/purpose |
|---|---|---|---|---|
| Steady State Zone 1 | 01 | Continuous, middle blue | None between intervals | 15–20 min recovery-focused example; 45–60+ min aerobic example; lower-demand continuous work |
| Steady State Zone 2 | 02 | Continuous, upper blue | None between intervals | Similar duration examples; sustained aerobic base work |
| Tempo Intervals | 03 | 10–15 sec, approximately 70% maximum speed | 60 sec active, toward middle blue | 10–20 reps; controlled faster movement |
| Blue Zone Repeats | 04 | 30–60 sec upper blue | 30–60 sec middle blue | 2–5 reps in source; low-intensity output variation |
| Green Power | 05 | 5–10 sec maximal effort | 40–60 sec toward middle blue; longer if needed | 10–20 reps; repeat explosive output |
| Green Endurance | 06 | 10–15 sec maximal effort | 60–90 sec toward upper blue | 10–20 reps; sustain short explosive efforts |
| Green Zone Repeats | 07–08 | 30–60 sec upper green | 30–60 sec lower green | Initially 3–5 reps; alternating sustained cardiovascular demand |
| Green Threshold | 09 | 3–6 min upper green standing / middle green seated | 2–4 min toward middle/upper blue | 2–5 reps; sustained output; source also specifies recovery score at least 90% |
| Red Power | 10 | 20–30 sec maximal effort | 2–3 min toward middle blue | 2–4 reps; high output bursts |
| Red Endurance | 11–12 | 40–60 sec maximal effort | 1–2 min toward upper blue | 2–4 reps; longer demanding bursts |
| Red Threshold | 13 | 3–6 min near lower red | 2–4 min toward upper blue | 2–4 reps; source inconsistently also says 100% max intensity |
| Red Max | 14 | 60–90 sec maximal effort | Several minutes toward blue; no exact range supplied | 2–4 reps; very demanding efforts |

Source course: https://trainwithmorpheus.com/courses/zone-based-interval-training/

The supplied screenshots retain the full captured text and images. Screen contents outside the lesson belong to the original captures. They are historical references, not current product requirements. Claims about recovery, isolated energy systems, threshold and maximum heart rate remain source claims. In particular, the Red Threshold instructions are internally inconsistent; do not convert them into a supposedly exact power target. An easy/medium/hard rating cannot establish a physiological threshold or replace measured heart-rate zones.

## Agreed Hybrid execution

The user wants very simple execution, with exactly three effort choices: **Easy / Medium / Hard**. No pain, technique, readiness or notes questions interrupt intervals. The first logged output for a new machine/method is used for calibration; no entered maximum is required.

1. Display the work duration, recovery duration, intended effort and output target if one exists.
2. Run the work timer. Capture interval-average watts or RPM when a compatible live connection actually supplies it. Otherwise allow a single output entry; never imply a Garmin connection automatically provides arbitrary gym-machine watts.
3. Start the recovery timer. Offer Easy / Medium / Hard, explicitly referring to the preceding work interval.
4. Calculate the next target during recovery and show it before the next work interval begins. The app suggests output; automatic machine control would require a separate supported integration.
5. Missing feedback holds the target. Missing output does not create an invented measurement.

Duration, repetitions and recovery are prescribed by the template. Within-session feedback primarily changes work output; it does not silently change all four variables. Athlete output overrides remain available.

## Target-relative feedback

| Intended effort | Easy reported | Medium reported | Hard reported |
|---|---|---|---|
| Easy | Hold | Small reduction | Small reduction; permit ending interval block |
| Medium | Small increase if output evidence is usable | Hold | Small reduction |
| Hard | Small increase only for a controlled hard format | Hold while gathering evidence, or small increase if clearly below target | Hold if the interval was completed as intended |

These are proposed product rules, not a published Morpheus algorithm. Completion and stable output matter: a failed or shortened interval must not earn an increase merely because the effort button says Easy. Hard is not failure. The app must not increase every easy interval when the session itself is meant to be easy.

No response means no effort-driven change. With failed completion or unusable measurements, hold or offer a conservative reduction without inventing the reason. Recovery-phase ease is not evidence that the preceding work interval was too easy.

## Calibration and output units

- Keep history specific to machine/model, exercise, work duration, recovery structure and effort target. A 15-second output is not a five-minute target.
- With no history, the athlete chooses an output at the prescribed effort. The first complete work interval supplies a provisional anchor. Repeat it to gather comparable evidence; it is not a maximum or a proven sustainable pace.
- For very short intervals, use multiple comparable observations before an upward change. Do not automatically chase the first burst or a noisy sensor reading.
- Watts are preferred when reliably available. RPM is usable only with a consistent machine and resistance setting; rowing stroke rate alone does not represent rowing power.
- For ordinary controlled intervals, the previously discussed 2–3% watt changes, 1–2 RPM changes and approximately 10% session bound are provisional engineering ideas. They are not validated physiological thresholds and should not be applied universally across machines or maximal formats. Exact constants remain to be tested and approved in the implementation specification.
- Store observed output separately from suggested output. Keep temporary within-session corrections separate from the longer-term starting target.

## Adapting the 12 references

| Reference | Hybrid template interpretation | Feedback behaviour |
|---|---|---|
| Steady State 1 | Easy continuous work | Easy holds; no repeated set prompts. Rate at the end or at an optional planned break. |
| Steady State 2 | Sustained easy base work | Easy holds. Do not infer the upper-blue boundary from the Easy button. |
| Tempo | Controlled short work / easy recovery | Medium work target can use target-relative adjustments after comparable intervals. This is closest to our moderately hard short efforts. |
| Blue Repeats | Alternating easy output ranges | Keep both phases easy; higher output phase does not require Medium feedback. |
| Green Power | Short power-repeat reference | Maximal intent makes ordinary easy-to-increase logic unsuitable. Track output repeatability; retain as a separate advanced format. |
| Green Endurance | Longer power-repeat reference | Same limitation; converting it to Medium effort creates a different, controlled-short-interval template. |
| Green Repeats | Alternating controlled work and easier output | Use distinct work/recovery targets. A Medium report can hold the work target. |
| Green Threshold | Longer sustained intervals | Adapt as controlled long intervals, including 4 × 5 min where programmed. Do not claim threshold calibration from three effort labels. |
| Red Power | Advanced short high-output format | Separate from base conditioning; no automatic escalation after every interval. |
| Red Endurance | Advanced longer high-output format | Hard can be expected; use completion/output repeatability, not Hard alone, to judge whether to reduce. |
| Red Threshold | Hard sustained-interval reference | Resolve contradictory source intent before assigning exact output; do not implement literal maximal sprint power for 3–6 minutes. |
| Red Max | Advanced maximal-interval reference | Do not require reaching a displayed maximum heart rate. No universal rating-driven escalation. |

The references expand the method library; they do not mean all 12 are scheduled into the user's two conditioning days. Existing weekly frequency and strength template remain the starting framework. Adaptations preserve the selected session purpose while keeping the same timer, output display and three-button feedback interface.

## Evidence and implementation status

User-supplied source material is preserved in full as screenshots. The reference timings are descriptive. The Hybrid adaptation is an original design proposal derived from the user's chosen workflow; it is not endorsed by Morpheus, a validated replica, or an implemented app. Existing research audits remain available for broader evidence. This update supersedes earlier conversational suggestions that Easy always increases output or Hard always decreases it.

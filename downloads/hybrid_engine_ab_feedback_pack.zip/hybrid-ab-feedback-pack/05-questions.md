# Questions for outside feedback

Please answer in order.

1. Are the **RPM deltas** (±0–2) too timid, about right, or too aggressive for short intervals on a fan/Echo bike?

2. Are the **watts multipliers** (~3–5% steps) about right for recreational hybrid athletes, or should they be smaller / asymmetric (easier to drop than to raise)?

3. Is using **template intended effort** (piece programmed as hard) the right “intended,” or should intended be inferred from today’s green/red zone job, or from the last few bouts?

4. Is the **early-end: no upward change** rule correct? Should incomplete bouts also block downward changes, or force a hold always?

5. Row/ski go through **split ↔ watts**. Any landmine if we keep deciding in watts then converting back?

6. Fan bike uses the same RPM table as Echo in the apply path. Keep one table or split machines?

7. If live HR is still a stub, can we still lock B, or must next-output wait until BPM is real?

8. Propose revised tables only if you reject ours — show the full 3×3, not one cell.

9. List **5 test cases** we should put in `node:test` before locking the B spec.

# Hybrid Engine — Scope C feedback pack

Please treat this as a **product design review** for Home / Me / Library — not a request to rewrite the live Engine logger.

## Locked already (do not reopen unless blocking)

**Scope A — live Engine logger** (`01-scope-A-live-logger-LOCKED.md`):

- Hole = BPM; horseshoe = today’s blue / green / red HR section; rail = watts or RPM + Work/Rest
- OLED paints `#00c2ff` / `#3dff7a` / `#ff2b2b`
- WHOOP does **not** appear on the logger; it only slides that day’s two HR lines
- Lifting has no HR
- Easy / Medium / Hard on Rest are effort chips, not zones

**Scope B — Adaptive Brain next watts/RPM** is a separate pack / conversation. Do not redesign those grids here unless a Scope C surface must expose them.

## What Scope C is

The rooms **around** the logger:

1. **Home** — WHOOP Sleep / Recovery / Strain dials; “Today’s zones” card (blue/green bpm lines); today call / calendar
2. **Me** — Connect / Sync WHOOP (official WHOOP UI lives here)
3. **Library** — Engine session templates; open question: organize / browse **blue / green / red methods** (Morph Hub–style method library was referenced historically; Hybrid must not brand Morph)

## What we need from you

Help us decide **what Scope C should be** before we write a design spec:

1. How Home should show readiness vs today’s HR zone lines (without fighting Scope A).
2. Whether Library should be method cards under Blue / Green / Red headings, simple Engine templates only, or something else.
3. Colour systems: WHOOP recovery colours (green ≥67 / yellow 34–66 / red ≤33) vs Morph recovery score colours (0–40 / 41–80 / 81–100) vs Hybrid OLED training zones — **never mix them on one dial**.
4. What is YAGNI for v1 of Scope C.

## Files

| File | Why |
| --- | --- |
| `00-README-for-ChatGPT.md` | This brief |
| `01-scope-A-live-logger-LOCKED.md` | Context — locked |
| `02-library-page-overrides.md` | Current Library chrome rules |
| `03-engine-page-chrome.md` | Logger paint lock (points at A) |
| `06-MASTER-brand-excerpt.md` | Track Dawn brand |
| `code/04-home-whoop-and-zones.js` | What Home already paints |
| `code/05-dailyZones.js` | How recovery slides logger lines |
| `07-morph-hub-bundle-listing.txt` | Optional: listing of Hub method screenshots from a prior pack (reference only) |
| `08-current-product-facts.md` | Plain facts about what ships today |
| `09-questions.md` | Exact questions to answer |
| `screens/` | Home / Library / Me / Morph Track page (reference only — not Hybrid chrome) |

## Desired answer shape

1. Recommended **Scope C v1** (in / out).
2. Home: keep / change for WHOOP dials + zone card.
3. Library: one concrete IA (information architecture).
4. Colour rules in one short table (which palette on which surface).
5. Top 3 risks of overbuilding C.
6. Do **not** write production code. Spec outline bullets are fine.

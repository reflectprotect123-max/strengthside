# Hybrid Engine — Scope C feedback pack (updated)

**Scope A and Scope B are LOCKED.** Do not reopen them unless something in Scope C is impossible without a conflict — then call the conflict explicitly.

Please treat this as a **product design review** for Home / Me / Library only.

## Locked (context only)

| Scope | What | Where in this zip |
| --- | --- | --- |
| **A** | Live Engine logger: BPM hole, blue/green/red HR section, rail watts/RPM, Rest EMH chips ≠ zones, lifting no HR, WHOOP not on logger | `locked/01-scope-A-live-logger.md` + `screens/hybrid/logger-*.png` |
| **B** | Adaptive Brain next watts/RPM after Easy/Medium/Hard (tables + early-end hold-upward) | `locked/02-scope-B-*.md` + `locked/02c/d` code excerpts |

## What Scope C is (open)

Rooms **around** the logger:

1. **Home** — WHOOP dials + “Today’s zones” card + calendar / today call  
2. **Me** — Connect / Sync WHOOP  
3. **Library** — Engine templates; open question whether Blue / Green / Red **method** browsing belongs here  

## Morph screenshots in this zip (REFERENCE ONLY)

These are **not** Hybrid chrome. No Morph branding in Hybrid. Use them to discuss Library IA and colour-system traps only.

| Folder | Contents |
| --- | --- |
| `screens/morph-hub-methods/` | 12 Hub interval method cards (Steady State → Red Max) + progression notes |
| `screens/morph-quick-start/` | Quick Start PDF page renders (Track recovery colours, Train gauge B/G/R) |
| `screens/hybrid/` | What Hybrid already ships (Home, Library, Me, logger zones, Rest EMH) |

**Critical colour warning:** Morph Track recovery score uses red/amber/green (0–40 / 41–80 / 81–100). WHOOP uses green ≥67 / yellow 34–66 / red ≤33. Hybrid OLED blue/green/red are **training HR zones** on the logger. Never mix those three systems on one dial.

## What we need from you

1. Scope C **v1** in/out list.  
2. Home: keep / change WHOOP dials + zone card (without fighting A).  
3. Library: one concrete IA (flat templates vs Blue/Green/Red method headings vs two lanes).  
4. If Library uses Blue/Green/Red: does that mean **HR zone job** (same as A) or **method family / difficulty**? Call the confusion.  
5. Colour rules table (which palette on which surface).  
6. Top 3 overbuild risks if we start from Hub screenshots.  
7. **Do not** write production code. **Do not** redesign A or B tables.

## Files

- `00-README-for-ChatGPT.md` — this brief  
- `locked/` — A + B (locked)  
- `03-library-page-overrides.md`, `04-engine-page-chrome.md`, `07-MASTER-brand-excerpt.md`  
- `code/05-home-whoop-and-zones.js`, `code/06-dailyZones.js`  
- `08-current-product-facts.md`, `09-questions.md`  
- `screens/` — Morph Hub + Quick Start + Hybrid  

Start with this README, then `09-questions.md`. Peek Morph Hub only when answering Library questions.

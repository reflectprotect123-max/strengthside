// Excerpt from apps/athlete/engine/engine.js
  function applyDecideNext(e, reportedEffort) {
    const K = kernel();
    if (!K || typeof K.decideNextEngine !== 'function') return null;
    const intended = e.effort || 'medium';
    const complete = e.workComplete !== false;
    if (e.modality === 'rpm' && e.target.rpm != null) {
      const out = K.decideNextEngine({
        machine: 'echo',
        intendedEffort: intended,
        reportedEffort,
        actualOutput: e.target.rpm,
        complete,
        unit: 'rpm',
      });
      return { ...e.target, rpm: out.nextOutput };
    }
    if (e.modality === 'watts' && e.target.watts != null) {
      const out = K.decideNextEngine({
        machine: 'concept2',
        intendedEffort: intended,
        reportedEffort,
        actualOutput: e.target.watts,
        complete,
        unit: 'watts',
      });
      return { ...e.target, watts: out.nextOutput };
    }
    if (e.modality === 'split' && e.target.splitSec != null) {
      const watts = wattsFromSplitSec(e.target.splitSec);
      const out = K.decideNextEngine({
        machine: 'concept2',
        intendedEffort: intended,
        reportedEffort,
        actualOutput: watts,
        complete,
        unit: 'watts',
      });
      return { ...emptyTarget(), splitSec: splitSecFromWatts(out.nextOutput) };
    }
    return null;
  }

  function recordEffort(log, reportedEffort, adaptive, now) {
    const s = clone(log);
    const e = s.engine;
    const bout = {
      effort: reportedEffort,
      watts: e.target.watts,
      splitSec: e.target.splitSec,
      rpm: e.target.rpm,
    };
    e.bouts.push(bout);
    if (!e.skipped) {
      const next = applyDecideNext(e, reportedEffort);
      if (next) e.target = next;
    }
    e.needsEffort = false;
    e.roundIndex += 1;
    const more = e.roundIndex < e.rounds && e.structure === 'intervals';
    if (more) {
      e.phase = 'rest';
      if (e.restEndsAt == null && e.restSec > 0) {
        e.restEndsAt = (now || Date.now()) + e.restSec * 1000;
      }
    } else {
      e.phase = 'done';
      s.completed = true;
      e.workEndsAt = null;
      e.restEndsAt = null;
    }
    return s;
  }


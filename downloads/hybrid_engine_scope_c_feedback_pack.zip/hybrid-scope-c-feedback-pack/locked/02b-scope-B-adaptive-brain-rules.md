# Adaptive Brain Engine rules (plain English)

## When they fire

After a work bout, on Rest, athlete taps Easy / Medium / Hard. That is **reported** effort.

The piece’s programmed effort (`easy` / `medium` / `hard` on the template) is **intended**.

Brain compares intended vs reported and moves the **next** target from the bout’s actual output (current target used as actual when applying from the logger path).

## RPM (Echo / fan path in code: `machine: 'echo'`)

Delta in whole RPM:

| Intended ↓ / Reported → | Easy | Medium | Hard |
| --- | --- | --- | --- |
| Easy | 0 | −1 | −2 |
| Medium | +1 | 0 | −1 |
| Hard | +2 | +1 | 0 |

## Watts (bike / Concept2-style; row/ski convert split → watts → decide → back to split)

Multiply, then round:

| Intended ↓ / Reported → | Easy | Medium | Hard |
| --- | --- | --- | --- |
| Easy | ×1.00 | ×0.97 | ×0.95 |
| Medium | ×1.03 | ×1.00 | ×0.97 |
| Hard | ×1.05 | ×1.03 | ×1.00 |

## Early end

If the athlete ended the interval early (`complete === false`), any **upward** change is blocked (hold same number). Downward changes still apply.

## Explicit non-goals of these rules

- Do not move blue / green / red HR cutoffs.
- Do not use WHOOP recovery for next watt/RPM (WHOOP only slides today’s HR lines in Scope A).
- Strength kg progression is a different path.

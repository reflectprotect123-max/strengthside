# Hybrid Engine — Adaptive Brain feedback pack

Please treat this as a **product + rules review**, not a request to rewrite the whole app.

## Who we are

Hybrid S&C / The Engine: interval logger for bike / Echo / row / ski. Athlete rates each work bout **Easy / Medium / Hard** on Rest. Adaptive Brain (`decideNextEngine`) sets the **next** watts or RPM.

We already locked **Scope A** (live glance screen: BPM hole, blue/green/red HR ruler, rail clock). See `01-engine-live-logger-spec-LOCKED.md`. Do **not** reopen that unless something in A blocks B.

## What we need from you now (Scope B)

Feedback on whether these **Adaptive Brain Engine rules** are sensible for recreational / serious conditioning, and what to change before we lock them in a B spec.

Focus:

1. The intended vs reported effort grids (RPM ± and watts ×).
2. The “ended early → no upward change” rule.
3. Using **programmed** piece effort as “intended” (template easy/medium/hard), not the athlete’s heart-rate zone.
4. Separating HR zones (A) from next-output (B) — is that the right split?
5. Gaps / risks: missing actual output, first bout with no history, row split conversion, fan vs Echo both on RPM table, etc.

## What we are NOT asking

- Do not redesign the horseshoe / OLED / WHOOP Me screen (Scope A is locked).
- Do not invent Morpheus branding or copy Morph’s recovery test.
- Do not expand into Library method lists or Home WHOOP chrome (Scope C) unless a B rule depends on it.
- Do not write production code. Prefer: verdict, risks, proposed table tweaks, test cases.

## Files in this zip

| File | Why |
| --- | --- |
| `00-README-for-ChatGPT.md` | This brief |
| `01-engine-live-logger-spec-LOCKED.md` | Scope A — context only |
| `02-brain-kernel-engine-rules.js` | Exact rules + `decideNextEngine` |
| `03-engine-apply-decide-next.js` | How the logger applies those rules (RPM / watts / split) |
| `04-rules-in-plain-english.md` | Same rules without code |
| `05-questions.md` | Exact questions to answer |

## Desired answer shape

1. **Keep / tweak / replace** for each table (RPM and watts).
2. **Keep / tweak / replace** for the early-end hold-upward rule.
3. Top **3 risks** if we ship these as-is.
4. **5 concrete test cases** (intended, reported, actual, complete?, expected next).
5. Anything that must wait for Scope C (or live HR) before B can be honest.

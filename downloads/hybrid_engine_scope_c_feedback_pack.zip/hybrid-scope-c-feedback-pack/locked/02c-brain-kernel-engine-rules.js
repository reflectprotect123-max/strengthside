// Excerpt from apps/athlete/engine/brain-kernel.js
  const rules = {
    conditioning: {
      echo_bike_rpm_multipliers: {
        easy: { easy: 0, medium: -1, hard: -2 },
        medium: { easy: 1, medium: 0, hard: -1 },
        hard: { easy: 2, medium: 1, hard: 0 },
      },
      concept2_power_multipliers: {
        easy: { easy: 1.0, medium: 0.97, hard: 0.95 },
        medium: { easy: 1.03, medium: 1.0, hard: 0.97 },
        hard: { easy: 1.05, medium: 1.03, hard: 1.0 },
      },
    },
  };

  function rank(effort) {
    return { easy: 0, medium: 1, hard: 2 }[effort];
  }

  function decideNextStrength(input) {
    // Load / reps / miss / effort only. Heart rate is not an input for lifting.
    const step = Number(input.equipmentStepKg) || 2.5;
    const suggested = Number(input.suggestedKg);
    const actual = input.actualKg == null ? null : Number(input.actualKg);
    const reference = actual == null || Number.isNaN(actual) ? suggested : actual;

    const missingEffort = !EFFORTS.includes(input.reportedEffort);
    const missingLoad = actual == null || Number.isNaN(actual);
    const missingReps = input.completedReps == null || Number.isNaN(Number(input.completedReps));
    const missedReps = !!input.miss || (
      input.completedReps != null &&
      input.targetReps != null &&
      Number(input.completedReps) < Number(input.targetReps)
    );

    if (missingLoad && !missedReps) {
      return { nextKg: suggested, hold: true, ruleVersion: RULE_VERSION };
    }
    if ((missingEffort || missingReps) && !missedReps) {
      return { nextKg: reference, hold: true, ruleVersion: RULE_VERSION };
    }
    if (missedReps) {
      return { nextKg: reference - step, hold: false, ruleVersion: RULE_VERSION };
    }

    const ir = rank(input.intendedEffort);
    const rr = rank(input.reportedEffort);
    if (rr < ir) return { nextKg: reference + step, hold: false, ruleVersion: RULE_VERSION };
    if (rr > ir) return { nextKg: reference - step, hold: false, ruleVersion: RULE_VERSION };
    return { nextKg: reference, hold: true, ruleVersion: RULE_VERSION };
  }

  function decideNextEngine(input) {
    const actual = input.actualOutput;
    if (actual == null || !EFFORTS.includes(input.reportedEffort)) {
      return { nextOutput: actual ?? null, unit: input.unit, ruleVersion: RULE_VERSION, hold: true };
    }
    const intended = input.intendedEffort;
    const reported = input.reportedEffort;
    if (input.machine === 'echo') {
      const delta = rules.conditioning.echo_bike_rpm_multipliers[intended][reported];
      if (!input.complete && delta > 0) {
        return { nextOutput: actual, unit: 'rpm', ruleVersion: RULE_VERSION, hold: true };
      }
      return { nextOutput: actual + delta, unit: 'rpm', ruleVersion: RULE_VERSION, hold: delta === 0 };
    }
    const factor = rules.conditioning.concept2_power_multipliers[intended][reported];
    if (!input.complete && factor > 1) {
      return { nextOutput: actual, unit: 'watts', ruleVersion: RULE_VERSION, hold: true };
    }
    return {
      nextOutput: Math.round(actual * factor),
      unit: 'watts',
      ruleVersion: RULE_VERSION,
      hold: factor === 1,
    };
  }


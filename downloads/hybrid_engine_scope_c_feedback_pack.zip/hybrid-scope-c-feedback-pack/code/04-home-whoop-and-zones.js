// Excerpt: apps/athlete/engine/app.js — Home WHOOP dials + Today's zones card
/** WHOOP recovery zones — green ≥67, yellow 34–66, red ≤33 (brand guidelines). */
function whoopRecoveryColor(recovery) {
  const v = num(recovery);
  if (!v) return '#16ec06';
  if (v >= 67) return '#16ec06';
  if (v >= 34) return '#ffde00';
  return '#ff0026';
}

function whoopDialSvg(opts = {}) {
  const size = opts.size || 104;
  const stroke = size >= 100 ? 7 : 6;
  const c = size / 2;
  const r = c - stroke / 2 - 1.5;
  const max = num(opts.max) || 100;
  const raw = opts.value;
  const has = raw != null && raw !== '' && Number.isFinite(Number(raw));
  const prog = has ? athClamp(num(raw) / max, 0, 1) : 0;
  const circ = 2 * Math.PI * r;
  const color = opts.color || '#9db4c8';
  const label = opts.label || '';
  const unit = opts.unit || '';
  const fid = `wg${Math.round(c)}${String(color).replace(/[^a-zA-Z0-9]/g, '').slice(0, 8)}`;
  const valHtml = has
    ? unit === '%'
      ? `<span class="ath-whoop-n">${Math.round(num(raw))}</span><small>%</small>`
      : Math.abs(num(raw) % 1) > 0.001
        ? num(raw).toFixed(1)
        : String(Math.round(num(raw)))
    : '—';
  const glow = has
    ? `<defs><filter id="${fid}" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`
    : '';
  const arc = has
    ? `<circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${circ}" stroke-dashoffset="${circ * (1 - prog)}" filter="url(#${fid})" style="filter:drop-shadow(0 0 6px ${color})"/>`
    : '';
  return `
    <div class="ath-whoop-dial">
      <div class="ath-whoop-dial-ring">
        <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" aria-hidden="true">
          ${glow}
          <g transform="rotate(-90 ${c} ${c})">
            <circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="#111113" stroke-width="${stroke}"/>
            ${arc}
          </g>
        </svg>
        <div class="ath-whoop-dial-val">${valHtml}</div>
      </div>
      <div class="ath-whoop-dial-lab">${esc(label)}</div>
    </div>`;
}

function longDateLabel(iso) {
  return parseDate(iso).toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
}

function topBarHtml() {
  return `
    <header class="home-top">
      <div class="home-brand">
        <span class="home-mark" aria-hidden="true">TH</span>
        <div class="home-brand-text" aria-label="HYBRID S&C, Engine">
          ${HybridSc.brandHtml('engine')}
        </div>
      </div>
      <div class="home-top-actions">
        <button type="button" class="month-btn" aria-label="Month">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M4 12h10M4 18h6"/></svg>
          <span>${esc(monthLabel(S.selectedDate))}</span>
        </button>
        <button type="button" class="today-btn" onclick="goToday()">Today</button>
        <button type="button" class="bell-btn" aria-label="Notifications">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a5 5 0 0 0-5 5v2.6c0 .8-.3 1.6-.8 2.2L4.5 15.5h15l-1.7-2.7a3.5 3.5 0 0 1-.8-2.2V8a5 5 0 0 0-5-5z"/><path d="M10 18a2 2 0 0 0 4 0"/></svg>
          <em class="bell-badge">${S.notifications || 0}</em>
        </button>
      </div>
    </header>`;
}

function gaugeRowHtml() {
  const c = dailyCheckin(S.selectedDate, false) || dailyCheckin(today(), false) || {};
  const m = metricsFromCheckin(c);
  return `
    <section class="ath-module-whoop" aria-label="WHOOP">
      <span class="ath-label">WHOOP</span>
      <div class="ath-whoop-wrap">
        <div class="ath-whoop-dials gauge-row">
          ${whoopDialSvg({ label: 'Sleep', value: m.sleepScore, max: 100, color: '#9db4c8', unit: '%', size: 104 })}
          ${whoopDialSvg({ label: 'Recovery', value: m.recovery, max: 100, color: whoopRecoveryColor(m.recovery), unit: '%', size: 104 })}
          ${whoopDialSvg({ label: 'Strain', value: m.strain, max: 21, color: '#1ba3ff', unit: '', size: 104 })}
        </div>
        ${todayCallHtml()}
      </div>
    </section>
    ${zonesCardHtml(c)}`;
}

function zoneProfile() {
  const z = S.settings?.zones || {};
  const c = dailyCheckin(S.selectedDate, false) || dailyCheckin(today(), false) || {};
  return {
    hrMax: num(z.hrMax) || 190,
    rhr28: num(z.rhr28) || num(c.restingHr) || 60,
    bgBase: num(z.bgBase) || 138,
    grBase: num(z.grBase) || 170.5,
  };
}

function zonesCardHtml(checkin) {
  if (!globalThis.HybridBrainKernel || typeof HybridBrainKernel.dailyZones !== 'function') return '';
  const profile = zoneProfile();
  const recovery = metricsFromCheckin(checkin || {}).recovery;
  const connected = !!S.settings?.whoop?.connected;
  const freshness = connected && recovery != null ? 'current' : 'missing';
  const zones = HybridBrainKernel.dailyZones({
    recovery,
    freshness,
    hrMax: profile.hrMax,
    rhr28: profile.rhr28,
    bgBase: profile.bgBase,
    grBase: profile.grBase,
  });
  const note = freshness === 'current' ? '' : ' · no WHOOP adjustment today';
  return `
    <section class="ath-zones" aria-label="Heart rate zones">
      <span class="ath-label">Today's zones</span>
      <p class="ath-zone-est">Estimated from baseline${note}</p>
      <ul>
        <li>Blue → ${Math.round(zones.bgToday)} bpm</li>
        <li>Green → ${Math.round(zones.grToday)} bpm</li>
      </ul>
    </section>`;
}


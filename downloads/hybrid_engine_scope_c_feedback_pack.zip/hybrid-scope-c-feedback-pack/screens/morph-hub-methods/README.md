# Morph Hub method screenshots + Engine progression pack

**For:** Adaptive Brain progression bundle  
**Assembled:** 2026-09-16  

## Start here

1. Read **`HOW-PROGRESSIONS-ARE-MADE.md`** (deep synthesis: Blue/Green/Red library shape, WHOOP gates, EMH Next tables, anchors, one-lever between-session, method ladder, gaps).  
2. Use **`screenshots/`** as visual Morph Hub method source (12 methods, easiest→hardest).  
3. Treat **`sources/`** as the authority copies behind the synthesis.

## Folder layout

```
morph-hub-method-screenshots/
  HOW-PROGRESSIONS-ARE-MADE.md   ← read first
  README.md                      ← this file
  screenshots/
    01-steady-state-zone-1.png … 12-red-max-intervals.png
  sources/
    00-FORMULAS-AND-RULES.md
    00-RULE-CONFIG.json
    00-HANDOFF.md
    …
```

## Library shape (Engine)

Three headings — **Blue · Green · Red** — listed easiest → hardest, then progressed across bands by Adaptive Brain:

| Band | Methods (order) |
| --- | --- |
| Blue | Steady State Z1 → Z2 → Tempo → Blue Zone Repeats |
| Green | Power → Endurance → Zone Repeats → Threshold |
| Red | Power → Endurance → Threshold → Max |

Athlete Library **works with** these sessions/methods; it does not invent progression. Progression logic belongs in Adaptive Brain.

## Screenshots

| # | Band | Method | File |
| --- | --- | --- | --- |
| 1 | blue | Steady State Zone 1 | `screenshots/01-steady-state-zone-1.png` |
| 2 | blue | Steady State Zone 2 | `screenshots/02-steady-state-zone-2.png` |
| 3 | blue | Tempo Intervals | `screenshots/03-tempo-intervals.png` |
| 4 | blue | Blue Zone Repeats | `screenshots/04-blue-zone-repeats.png` |
| 5 | green | Green Power Intervals | `screenshots/05-green-power-intervals.png` |
| 6 | green | Green Endurance Intervals | `screenshots/06-green-endurance-intervals.png` |
| 7 | green | Green Zone Repeats | `screenshots/07-green-zone-repeats.png` |
| 8 | green | Green Threshold Intervals | `screenshots/08-green-threshold-intervals.png` |
| 9 | red | Red Power Intervals | `screenshots/09-red-power-intervals.png` |
| 10 | red | Red Endurance Intervals | `screenshots/10-red-endurance-intervals.png` |
| 11 | red | Red Threshold Intervals | `screenshots/11-red-threshold-intervals.png` |
| 12 | red | Red Max Intervals | `screenshots/12-red-max-intervals.png` |

Duplicates omitted: second Green Zone Repeats frame; byte-identical Red Endurance duplicate.

## Branding / science honesty

- Do **not** brand product UI as Morpheus.  
- Morph supplies **method structure** (work/rest/purpose). Hybrid owns EMH, anchors, WHOOP HRR shift, and progression heuristics.  
- Exact constants (3% watts, 1 RPM, 2 observations, 90% completion, 5% fade, +5 min, WHOOP shift points) are **product heuristics**, not published Morph/WHOOP formulas.

## Provenance

Screenshots: user-supplied Morpheus Hub lesson captures (12 Sep 2026), Engine-owned.  
Contracts: Adaptive Brain / Hybrid Conditioning co-located package `C/00-*` and related Cond docs.  
Kernel: `strengthside/apps/athlete/engine/brain-kernel.js` snapshot.

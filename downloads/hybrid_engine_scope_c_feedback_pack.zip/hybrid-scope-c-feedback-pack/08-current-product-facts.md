# What ships today (facts)

## Locked scopes

- **A** — Live Engine logger (spec in `locked/01-…`). Lamp follows HR; rail is output + Work/Rest.
- **B** — After Rest Easy/Medium/Hard, Adaptive Brain moves next RPM (±) or watts (×). Early end blocks upward changes. See `locked/02b-…`.

## Home (Engine app) — Scope C surface

- Calendar week  
- WHOOP: Sleep %, Recovery %, Strain (0–21)  
- Recovery dial colour = **WHOOP** thresholds: green ≥67, yellow 34–66, red ≤33  
- “Today’s zones” card: Blue → bpm, Green → bpm from `dailyZones` (bases ~138 / 170.5, WHOOP slides when connected + that day)

## Me — Scope C surface

- WHOOP Connect / Sync only for readiness link  
- Official WHOOP UX lives here, not on the logger  

## Library — Scope C surface (open design)

- Engine session templates: create / edit / schedule  
- Chrome rules: reuse first; Schedule primary (`03-library-page-overrides.md`)  
- **Not designed yet:** Blue / Green / Red method library from Hub screenshots  

## Colour systems (do not mix)

| System | Palette | Hybrid home today |
| --- | --- | --- |
| WHOOP recovery | ≥67 green / 34–66 yellow / ≤33 red | Home Recovery dial |
| Hybrid training zones | OLED `#00c2ff` / `#3dff7a` / `#ff2b2b` | Logger only (A) |
| Morph recovery score | 0–40 red / 41–80 amber / 81–100 green | **Nowhere** in Hybrid |
| Morph Train zones | blue / green / red HR sections | Meaning inspired A; Hybrid paints |

## Morph assets in this pack

- `screens/morph-hub-methods/` — 12 method screenshots + HOW-PROGRESSIONS-ARE-MADE.md  
- `screens/morph-quick-start/` — Quick Start pages (Track + Train)  

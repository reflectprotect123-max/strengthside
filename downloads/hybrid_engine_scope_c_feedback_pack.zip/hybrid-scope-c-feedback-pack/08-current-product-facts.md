# What ships today (facts)

## Home (Engine app)

- Calendar week
- WHOOP row: Sleep %, Recovery %, Strain (0–21)
- Recovery dial colour uses **WHOOP brand thresholds**: green ≥67, yellow 34–66, red ≤33 (`whoopRecoveryColor`)
- “Today’s zones” card lists estimated Blue → bpm and Green → bpm from `dailyZones` (bases 138 / 170.5, shifted when WHOOP connected + that day’s recovery present)
- Today call copy can say connect WHOOP under Me

## Me

- WHOOP Connect / Sync
- Official WHOOP connection UX lives here (not on the logger)

## Library

- Engine session templates: create / edit / schedule
- Design page (`02-library-page-overrides.md`): reuse templates first; Schedule is primary CTA
- **Not yet designed:** Blue / Green / Red method library headings, Hub-style method cards, progression curriculum UI
- Engine compile **skips** lift blocks; Library can still hold Engine pieces only for Engine locker

## Colour systems (must not mix)

| System | Palette | Where it belongs today |
| --- | --- | --- |
| WHOOP recovery | green ≥67, yellow 34–66, red ≤33 | Home Recovery dial, Me |
| Hybrid training zones | OLED blue / green / red HR bands | Live Engine logger (Scope A) |
| Morph recovery score (reference only) | red 0–40, amber 41–80, green 81–100 | **Not** Hybrid — Morph Quick Start Track screen |
| Morph Train zones (reference) | blue recovery / green conditioning / red overload | Inspired Scope A gauge meaning, Hybrid paints |

## Related prior packs

Adaptive Brain / Scope B feedback zip (separate):  
`https://github.com/reflectprotect123-max/strengthside/raw/cursor/engine-rest-overlay-fb1e/downloads/hybrid_engine_ab_feedback_pack.zip`

Morph Hub progression screenshot zip (methods reference, not Hybrid UI):  
`https://github.com/reflectprotect123-max/strengthside/raw/cursor/morph-progression-bundle-fb1e/downloads/morph_hub_progression_bundle.zip`

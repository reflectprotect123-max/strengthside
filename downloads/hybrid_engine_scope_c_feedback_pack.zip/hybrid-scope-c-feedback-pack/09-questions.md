# Questions for outside feedback (Scope C)

**A and B are locked.** Do not propose new horseshoe behaviour or new Adaptive Brain tables unless you find a hard conflict with C — if so, name the conflict in one sentence and stop.

Answer in order. Prefer concrete choices.

## Home

1. Keep three WHOOP dials as readiness hero, or shrink them so today’s session / zones is the hero?

2. “Today’s zones” card on Home: keep / move to Me or Training / remove?

3. WHOOP disconnected: hide dials / empty + Connect CTA / stock zone lines only?

## Me

4. For C v1, anything beyond Connect / Sync WHOOP? (zone lines, HRmax/RHR edit, nothing else)

## Library (use Morph Hub screenshots as reference only)

5. Pick one IA for Engine Library v1:
   - **A.** Flat Engine templates only (polish what we have)
   - **B.** Three headings Blue / Green / Red with method cards (easiest → hardest)
   - **C.** Two lanes: “My templates” + “Method library”
   - **D.** Other (≤5 bullets)

6. If B or C: do Blue/Green/Red mean **HR zone job** (same as Scope A) or **method family / difficulty**? Call any naming collision with the logger lamp.

7. Library content: Hub-style prescription text, or only Hybrid Engine fields (machine, workSec, restSec, rounds, effort)?

8. Looking at the 12 Hub screenshots: which methods are **in** for Hybrid Library v1, which are **later / never**?

## Colour & brand

9. Fill:

| Palette | Allowed on |
| --- | --- |
| WHOOP green/yellow/red | ? |
| Hybrid OLED B/G/R | ? |
| Morph amber recovery score | ? |

10. How do we stop Home from teaching “Recovery % colour = training zone colour”?

## Scope control

11. Scope C **v1** in-list vs later-list (two short lists).

12. Top 3 overbuild risks if we start from Morph Hub screenshots.

13. Anything that must wait for live HR strap before C Library/Home can be honest? (B is already locked without requiring strap.)

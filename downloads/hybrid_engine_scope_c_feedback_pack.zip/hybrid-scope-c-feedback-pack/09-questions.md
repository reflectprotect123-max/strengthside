# Questions for outside feedback (Scope C)

Answer in order. Prefer concrete choices over essays.

## Home

1. Should Home keep the three WHOOP dials (Sleep / Recovery / Strain) as the readiness hero, or shrink them so “Today’s zones” / today’s session is the hero?

2. Is the “Today’s zones” card (Blue → bpm, Green → bpm) useful on Home, redundant with the logger, or should it move to Me / Training only?

3. When WHOOP is disconnected, should Home hide the dials, show empties with Connect CTA, or show stock zone lines only?

## Me

4. Anything missing on Me besides Connect / Sync WHOOP for Scope C v1? (e.g. show today’s zone lines, HR max / RHR edit, nothing else)

## Library

5. Pick one IA for Engine Library v1:
   - **A.** Flat Engine session templates only (what we have, polish chrome)
   - **B.** Three headings Blue / Green / Red with method cards under each (easiest → hardest), tapping opens or builds an Engine template
   - **C.** Two lanes: “My templates” + “Method library” (B nested under Methods)
   - **D.** Other (describe in ≤5 bullets)

6. If B or C: should Blue/Green/Red mean **HR zone job** (same as Scope A), or **session difficulty / method family**? Those are not the same — call the confusion if you see it.

7. Should Library show Morph Hub–style interval prescriptions (work/rest/reps text), or only Hybrid Engine pieces (machine, workSec, restSec, rounds, effort)?

## Colour & brand

8. Fill this table with one line each — where each palette may appear:

| Palette | Allowed on |
| --- | --- |
| WHOOP green/yellow/red | ? |
| Hybrid OLED B/G/R | ? |
| Morph amber recovery score | ? (recommend: nowhere in Hybrid) |

9. Any Home layout that would accidentally teach “Recovery % = training zone colour”? How do we prevent that?

## Scope control

10. What belongs in **Scope C v1** vs **later**? Give two short lists.

11. What must wait until live HR (strap) or Scope B (next watts) before C can be honest?

12. Top 3 overbuild risks if we start from Morph Hub screenshots.

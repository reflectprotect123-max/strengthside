Hybrid Strength 1.2.3 adds a five-level difficulty slider, simple next-set load suggestions, and automatic rest after logging a set. Your manually chosen rest duration is reused within the exercise; Next clears the timer and rest selection. Carries and timed holds retain their existing behavior.

Download Hybrid-Strength-1.2.3.apk under Assets. This is a complete test APK based on the verified Hybrid Strength 1.2.2 native shell. Its updated packaged web source is included separately; the release tag points to the original shell's base commit, not the full modified web source.

Validation: mobile browser workout flow, touch slider, saved-set editing, reload persistence, timer expiry/reuse/reset, summary, template difficulty selection, APK asset integrity, 16 KB ZIP alignment, and Android v2/v3 signatures passed. Physical-device installation, background/lock-screen timers, and account sync have not been tested.

Signing: this APK uses a new locally retained signing key. It cannot update the previously signed 1.2.2 installation in place. Preserve/export local logs before removing any old installation; uninstalling can erase them. The 1 kg load steps are demonstration logic, not Peak Strength's private algorithm or a complete adaptive training brain.

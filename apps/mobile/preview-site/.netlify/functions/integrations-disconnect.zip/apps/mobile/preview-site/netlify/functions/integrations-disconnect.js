var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/integrations-disconnect.mjs
var integrations_disconnect_exports = {};
__export(integrations_disconnect_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(integrations_disconnect_exports);

// netlify/functions/_hybrid-proxy.mjs
var HYBRID_ORIGIN = "https://thehybridengine1.netlify.app";
async function proxyHybrid(event, functionName) {
  const method = (event.httpMethod || "GET").toUpperCase();
  if (method === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET,POST,OPTIONS",
        "access-control-allow-headers": "authorization,content-type",
        "access-control-max-age": "86400"
      },
      body: ""
    };
  }
  const auth = event.headers.authorization || event.headers.Authorization || "";
  const params = event.queryStringParameters || {};
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v != null) qs.set(k, String(v));
  }
  const q = qs.toString();
  const url = `${HYBRID_ORIGIN}/.netlify/functions/${functionName}${q ? `?${q}` : ""}`;
  const headers = { accept: "application/json" };
  if (auth) headers.authorization = auth;
  if (event.headers["content-type"]) headers["content-type"] = event.headers["content-type"];
  let body;
  if (method !== "GET" && method !== "HEAD") {
    body = event.isBase64Encoded ? Buffer.from(event.body || "", "base64") : event.body;
  }
  const upstream = await fetch(url, { method, headers, body, redirect: "manual" });
  const text = await upstream.text();
  const outHeaders = {
    "content-type": upstream.headers.get("content-type") || "application/json; charset=utf-8",
    "cache-control": "no-store"
  };
  const location = upstream.headers.get("location");
  if (location) outHeaders.location = location;
  return {
    statusCode: upstream.status,
    headers: outHeaders,
    body: text
  };
}

// netlify/functions/integrations-disconnect.mjs
async function handler(event) {
  return proxyHybrid(event, "integrations-disconnect");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
